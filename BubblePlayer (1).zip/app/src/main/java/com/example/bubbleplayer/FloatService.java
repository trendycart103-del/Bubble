package com.example.bubbleplayer;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;

public class FloatService extends Service {
    WindowManager wm; FrameLayout root; WindowManager.LayoutParams lp;
    CoverView small, big; LinearLayout panel; TextView title; SeekBar seek;
    IconButton prev, play, next; boolean expanded;
    float dx, dy; int ox, oy; boolean moved;
    Runnable ui = this::refresh;

    @Override public IBinder onBind(Intent i) { return null; }

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override public int onStartCommand(Intent i, int f, int id) {
        PlayerCore.init(this);
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("bp", "Bubble Player", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "bp").setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Bubble Player চলছে").setContentIntent(pi).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(1, n);
        if (root == null && Settings.canDrawOverlays(this)) setup();
        return START_STICKY;
    }

    void setup() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        small = new CoverView(this);
        small.setLayoutParams(new FrameLayout.LayoutParams(dp(64), dp(64)));
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEE111A24); bg.setCornerRadius(dp(30)); bg.setStroke(dp(1), 0x55FFFFFF);
        panel.setBackground(bg);
        panel.setLayoutParams(new FrameLayout.LayoutParams(dp(260), -2));
        panel.setVisibility(View.GONE);
        big = new CoverView(this);
        panel.addView(big, new LinearLayout.LayoutParams(dp(110), dp(110)));
        title = new TextView(this);
        title.setTextColor(Color.WHITE); title.setSingleLine(true); title.setEllipsize(TextUtils.TruncateAt.END);
        title.setGravity(Gravity.CENTER); title.setPadding(0, dp(8), 0, 0);
        panel.addView(title, new LinearLayout.LayoutParams(-1, -2));
        seek = new SeekBar(this);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { if (u) PlayerCore.seek(p); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        panel.addView(seek, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        prev = new IconButton(this, 0); play = new IconButton(this, 1); next = new IconButton(this, 2);
        prev.setOnClickListener(v -> PlayerCore.step(-1));
        play.setOnClickListener(v -> PlayerCore.toggle());
        next.setOnClickListener(v -> PlayerCore.step(1));
        row.addView(prev, new LinearLayout.LayoutParams(dp(52), dp(52)));
        row.addView(play, new LinearLayout.LayoutParams(dp(68), dp(68)));
        row.addView(next, new LinearLayout.LayoutParams(dp(52), dp(52)));
        panel.addView(row);
        root = new FrameLayout(this);
        root.addView(small); root.addView(panel);
        lp = new WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START; lp.x = 20; lp.y = 300;
        root.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dx = e.getRawX(); dy = e.getRawY(); ox = lp.x; oy = lp.y; moved = false; return true;
                case MotionEvent.ACTION_MOVE:
                    if (Math.abs(e.getRawX() - dx) > 12 || Math.abs(e.getRawY() - dy) > 12) moved = true;
                    if (moved) { lp.x = ox + (int) (e.getRawX() - dx); lp.y = oy + (int) (e.getRawY() - dy); wm.updateViewLayout(root, lp); }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved && !expanded) expand(true); return true;
                case MotionEvent.ACTION_OUTSIDE:
                    if (expanded) expand(false); return true;
            }
            return false;
        });
        wm.addView(root, lp);
        PlayerCore.ls.add(ui);
        refresh();
    }

    void expand(boolean b) {
        expanded = b;
        small.setVisibility(b ? View.GONE : View.VISIBLE);
        panel.setVisibility(b ? View.VISIBLE : View.GONE);
        if (b) {
            DisplayMetrics m = getResources().getDisplayMetrics();
            lp.x = Math.max(0, Math.min(lp.x, m.widthPixels - dp(260)));
        }
        wm.updateViewLayout(root, lp);
    }

    void refresh() {
        if (root == null) return;
        boolean pl = PlayerCore.playing();
        int a = PlayerCore.accent();
        small.set(PlayerCore.cover, pl, a);
        big.set(PlayerCore.cover, pl, a);
        title.setText(PlayerCore.title());
        prev.set(pl, a); next.set(pl, a); play.set(pl, a);
        if (PlayerCore.mp != null) {
            try { seek.setMax(PlayerCore.mp.getDuration()); seek.setProgress(PlayerCore.mp.getCurrentPosition()); } catch (Exception ignored) {}
        }
    }

    @Override public void onDestroy() {
        PlayerCore.ls.remove(ui);
        if (root != null) { wm.removeView(root); root = null; }
        super.onDestroy();
    }
}
