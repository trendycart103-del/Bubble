package com.example.bubbleplayer;

import android.content.Context;
import android.graphics.*;
import android.view.View;

public class CoverView extends View {
    Bitmap bmp; boolean spin; int color = 0xFF4FC3F7; float ang;
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    Matrix m = new Matrix();

    public CoverView(Context c) {
        super(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        ring.setStyle(Paint.Style.STROKE);
    }

    void set(Bitmap b, boolean s, int col) {
        boolean again = s && !spin;
        bmp = b; spin = s; color = col;
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), cx = w / 2, cy = getHeight() / 2, R = w / 2 - w * 0.06f;
        ring.setStrokeWidth(w * 0.035f);
        ring.setColor(color);
        ring.setShadowLayer(w * 0.05f, 0, 0, color);
        c.drawCircle(cx, cy, R + w * 0.025f, ring);
        c.save();
        c.rotate(ang, cx, cy);
        if (bmp != null) {
            BitmapShader sh = new BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            float sc = 2 * R / Math.min(bmp.getWidth(), bmp.getHeight());
            m.reset(); m.setScale(sc, sc);
            m.postTranslate(cx - bmp.getWidth() * sc / 2, cy - bmp.getHeight() * sc / 2);
            sh.setLocalMatrix(m);
            p.setShader(sh);
            c.drawCircle(cx, cy, R, p);
        } else {
            p.setShader(new LinearGradient(cx - R, cy - R, cx + R, cy + R, color, 0xFF1B1B3A, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, R, p);
            p.setShader(null);
            p.setColor(0xCCFFFFFF); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(R);
            c.drawText("♪", cx, cy + R * 0.35f, p);
        }
        p.setShader(null);
        c.restore();
        p.setColor(0xFF0B1220);
        c.drawCircle(cx, cy, R * 0.13f, p);
        if (spin) { ang = (ang + 0.8f) % 360; postInvalidateOnAnimation(); }
    }
}
