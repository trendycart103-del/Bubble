package com.example.bubbleplayer;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.util.Random;

public class BubbleView extends View {
    float[] x, y, r, s, ph;
    int count = 30, c1 = 0xFF0F2027, c2 = 0xFF2C5364, bc = 0xFF4FC3F7;
    float speed = 3;
    boolean playing;
    Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG), bg = new Paint();
    Random rnd = new Random();

    public BubbleView(Context c) {
        super(c);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(3);
    }

    public void config(int count, float speed, int c1, int c2, int bc) {
        this.count = count; this.speed = speed; this.c1 = c1; this.c2 = c2; this.bc = bc;
        bg.setShader(new LinearGradient(0, 0, 0, Math.max(getHeight(), 1), c1, c2, Shader.TileMode.CLAMP));
        init();
    }

    void init() {
        x = new float[count]; y = new float[count]; r = new float[count]; s = new float[count]; ph = new float[count];
        for (int i = 0; i < count; i++) spawn(i, true);
    }

    void spawn(int i, boolean anywhere) {
        int w = getWidth() > 0 ? getWidth() : 1080, h = getHeight() > 0 ? getHeight() : 1920;
        r[i] = 20 + rnd.nextFloat() * 70;
        x[i] = rnd.nextFloat() * w;
        y[i] = anywhere ? rnd.nextFloat() * h : h + r[i];
        s[i] = 0.5f + rnd.nextFloat();
        ph[i] = rnd.nextFloat() * 6.28f;
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        bg.setShader(new LinearGradient(0, 0, 0, h, c1, c2, Shader.TileMode.CLAMP));
        init();
    }

    @Override protected void onDraw(Canvas c) {
        c.drawRect(0, 0, getWidth(), getHeight(), bg);
        float pulse = playing ? 1 + 0.07f * (float) Math.sin(System.currentTimeMillis() / 250.0) : 1;
        float mul = playing ? 1.8f : 1f;
        for (int i = 0; i < count; i++) {
            y[i] -= s[i] * speed * mul;
            x[i] += Math.sin(ph[i] + y[i] / 80) * 0.8f;
            if (y[i] < -r[i]) spawn(i, false);
            float rr = r[i] * pulse;
            fill.setColor(bc); fill.setAlpha(55);
            c.drawCircle(x[i], y[i], rr, fill);
            line.setColor(bc); line.setAlpha(170);
            c.drawCircle(x[i], y[i], rr, line);
            fill.setColor(Color.WHITE); fill.setAlpha(120);
            c.drawCircle(x[i] - rr * 0.35f, y[i] - rr * 0.35f, rr * 0.15f, fill);
        }
        postInvalidateOnAnimation();
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            for (int i = 0; i < count; i++) {
                float dx = e.getX() - x[i], dy = e.getY() - y[i];
                if (dx * dx + dy * dy < r[i] * r[i]) spawn(i, false);
            }
            return true;
        }
        return super.onTouchEvent(e);
    }
}
