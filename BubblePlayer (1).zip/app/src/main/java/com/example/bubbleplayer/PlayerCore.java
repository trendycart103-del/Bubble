package com.example.bubbleplayer;

import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.widget.Toast;
import java.util.ArrayList;

public class PlayerCore {
    static final int[][] THEMES = {
        {0xFF0F2027, 0xFF2C5364, 0xFF4FC3F7}, {0xFF3A1C71, 0xFFD76D77, 0xFFFFAF7B},
        {0xFF000000, 0xFF434343, 0xFFFFFFFF}, {0xFF134E5E, 0xFF71B280, 0xFFB9FBC0},
        {0xFF42275A, 0xFF734B6D, 0xFFF48FB1}};
    static Context ctx; static SharedPreferences sp; static Handler h;
    static MediaPlayer mp; static int idx = -1; static Bitmap cover; static long sleepEnd;
    static ArrayList<String> titles = new ArrayList<>();
    static ArrayList<Uri> uris = new ArrayList<>();
    static ArrayList<Runnable> ls = new ArrayList<>();

    static void init(Context c) {
        if (ctx != null) return;
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences("cfg", 0);
        h = new Handler(Looper.getMainLooper());
        tick();
    }
    static int accent() { return THEMES[sp.getInt("theme", 0)][2]; }
    static boolean playing() { try { return mp != null && mp.isPlaying(); } catch (Exception e) { return false; } }
    static String title() { return idx >= 0 ? titles.get(idx) : "গান বেছে নিন"; }

    static void load() {
        titles.clear(); uris.clear();
        try (Cursor c = ctx.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE},
                MediaStore.Audio.Media.IS_MUSIC + "!=0", null, MediaStore.Audio.Media.TITLE)) {
            while (c != null && c.moveToNext()) {
                uris.add(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(0)));
                titles.add(c.getString(1));
            }
        }
        fire();
    }

    static void start(int i) {
        try {
            if (mp != null) mp.release();
            idx = i;
            mp = new MediaPlayer();
            mp.setDataSource(ctx, uris.get(i));
            mp.prepare();
            mp.setOnCompletionListener(m -> step(1));
            mp.start();
            loadCover(uris.get(i));
        } catch (Exception e) {
            Toast.makeText(ctx, "চালানো যায়নি", Toast.LENGTH_SHORT).show();
        }
        fire();
    }

    static void loadCover(Uri u) {
        cover = null;
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(ctx, u);
            byte[] b = r.getEmbeddedPicture();
            if (b != null) {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inSampleSize = 2;
                cover = BitmapFactory.decodeByteArray(b, 0, b.length, o);
            }
        } catch (Exception ignored) {
        } finally { r.release(); }
    }

    static void step(int d) { if (!uris.isEmpty()) start((idx + d + uris.size()) % uris.size()); }
    static void toggle() {
        if (mp == null) { if (!uris.isEmpty()) start(0); return; }
        if (playing()) mp.pause(); else mp.start();
        fire();
    }
    static void pause() { if (playing()) mp.pause(); fire(); }
    static void seek(int p) { if (mp != null) mp.seekTo(p); }
    static void setSleep(int min) {
        sleepEnd = min > 0 ? System.currentTimeMillis() + min * 60000L : 0;
        Toast.makeText(ctx, min > 0 ? min + " মিনিট পরে গান বন্ধ হবে" : "টাইমার বাতিল", Toast.LENGTH_SHORT).show();
    }
    static String sleepLeft() {
        if (sleepEnd <= 0) return "";
        long l = (sleepEnd - System.currentTimeMillis()) / 1000;
        return "⏰ " + l / 60 + ":" + String.format("%02d", Math.max(l % 60, 0));
    }
    static void fire() { for (Runnable r : new ArrayList<>(ls)) r.run(); }
    static void tick() {
        if (sleepEnd > 0 && System.currentTimeMillis() >= sleepEnd) {
            sleepEnd = 0; pause();
            Toast.makeText(ctx, "টাইমার শেষ, গান বন্ধ", Toast.LENGTH_LONG).show();
        }
        fire();
        h.postDelayed(PlayerCore::tick, 500);
    }
}
