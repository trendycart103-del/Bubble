package com.example.bubbleplayer;

import android.content.Context;
import android.graphics.*;
import android.view.View;

public class IconButton extends View {
    int type, color = 0xFF4FC3F7; boolean playing;
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public IconButton(Context c, int type) {
        super(c);
        this.type = type;
        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    void set(boolean playing, int color) { this.playing = playing; this.color = color; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), cx = w / 2, cy = getHeight() / 2, r = w / 2 * 0.84f;
        int dark = Color.argb(230, Color.red(color) / 3, Color.green(color) / 3, Color.blue(color) / 3);
        p.setStyle(Paint.Style.FILL);
        p.setShadowLayer(w * 0.08f, 0, 0, color);
        p.setShader(new RadialGradient(cx - r / 3, cy - r / 3, r * 1.4f, color & 0x00FFFFFF | 0xDD000000, dark, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, p);
        p.setShader(null); p.clearShadowLayer();
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w * 0.03f); p.setColor(0xCCFFFFFF);
        c.drawCircle(cx, cy, r, p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE);
        float s = r * 0.42f;
        Path t = new Path();
        if (type == 1) {
            if (playing) {
                c.drawRoundRect(cx - s * 0.8f, cy - s, cx - s * 0.2f, cy + s, 6, 6, p);
                c.drawRoundRect(cx + s * 0.2f, cy - s, cx + s * 0.8f, cy + s, 6, 6, p);
            } else {
                t.moveTo(cx - s * 0.6f, cy - s); t.lineTo(cx + s, cy); t.lineTo(cx - s * 0.6f, cy + s); t.close();
                c.drawPath(t, p);
            }
        } else if (type == 0 || type == 2) {
            float d = type == 2 ? 1 : -1;
            t.moveTo(cx - d * s * 0.3f, cy - s * 0.8f); t.lineTo(cx + d * s * 0.7f, cy); t.lineTo(cx - d * s * 0.3f, cy + s * 0.8f); t.close();
            c.drawPath(t, p);
            float bx = cx - d * s * 0.7f;
            c.drawRoundRect(bx - s * 0.12f, cy - s * 0.8f, bx + s * 0.12f, cy + s * 0.8f, 4, 4, p);
        } else {
            p.setTextAlign(Paint.Align.CENTER); p.setTextSize(r * 1.1f);
            c.drawText("⚙", cx, cy + r * 0.38f, p);
        }
    }
}
