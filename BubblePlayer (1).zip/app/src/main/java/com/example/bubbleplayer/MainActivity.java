package com.example.bubbleplayer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    BubbleView bv; CoverView cover; TextView name, time; SeekBar seek;
    IconButton prev, play, next, gear;
    boolean askedOverlay;
    Runnable ui = this::refresh;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        PlayerCore.init(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        FrameLayout root = new FrameLayout(this);
        bv = new BubbleView(this);
        root.addView(bv);
        applyCfg();
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(24), dp(40), dp(24), dp(56));
        col.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1));
        cover = new CoverView(this);
        col.addView(cover, new LinearLayout.LayoutParams(dp(270), dp(270)));
        name = new TextView(this);
        name.setTextColor(0xFFFFFFFF); name.setTextSize(22); name.setGravity(Gravity.CENTER);
        name.setPadding(0, dp(20), 0, dp(4)); name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        col.addView(name, new LinearLayout.LayoutParams(-1, -2));
        time = new TextView(this);
        time.setTextColor(0xCCFFFFFF); time.setGravity(Gravity.CENTER);
        col.addView(time, new LinearLayout.LayoutParams(-1, -2));
        col.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1));
        seek = new SeekBar(this);
        col.addView(seek, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        prev = new IconButton(this, 0); play = new IconButton(this, 1); next = new IconButton(this, 2);
        prev.setOnClickListener(v -> PlayerCore.step(-1));
        play.setOnClickListener(v -> PlayerCore.toggle());
        next.setOnClickListener(v -> PlayerCore.step(1));
        LinearLayout.LayoutParams s = new LinearLayout.LayoutParams(dp(76), dp(76));
        LinearLayout.LayoutParams L = new LinearLayout.LayoutParams(dp(104), dp(104));
        s.setMargins(dp(10), 0, dp(10), 0); L.setMargins(dp(10), 0, dp(10), 0);
        row.addView(prev, s); row.addView(play, L); row.addView(next, new LinearLayout.LayoutParams(s));
        col.addView(row);
        root.addView(col);
        gear = new IconButton(this, 3);
        gear.setOnClickListener(v -> showSettings());
        FrameLayout.LayoutParams g = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP | Gravity.END);
        g.setMargins(0, dp(40), dp(20), 0);
        root.addView(gear, g);
        setContentView(root);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int p, boolean u) { if (u) PlayerCore.seek(p); }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        String perm = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(perm) == 0) PlayerCore.load();
        else if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{perm, Manifest.permission.POST_NOTIFICATIONS}, 1);
        else requestPermissions(new String[]{perm}, 1);
    }

    @Override public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        if (r.length > 0 && r[0] == 0) PlayerCore.load();
        else Toast.makeText(this, "গান পড়তে অনুমতি দরকার", Toast.LENGTH_LONG).show();
    }

    @Override protected void onStart() { super.onStart(); PlayerCore.ls.add(ui); refresh(); }
    @Override protected void onStop() { super.onStop(); PlayerCore.ls.remove(ui); }

    @Override protected void onResume() {
        super.onResume();
        if (Settings.canDrawOverlays(this)) startForegroundService(new Intent(this, FloatService.class));
        else if (!askedOverlay) {
            askedOverlay = true;
            Toast.makeText(this, "বাবল দেখানোর অনুমতি চালু করুন", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        }
    }

    void applyCfg() {
        int[] t = PlayerCore.THEMES[PlayerCore.sp.getInt("theme", 0)];
        bv.config(PlayerCore.sp.getInt("count", 30), PlayerCore.sp.getInt("speed", 3), t[0], t[1], t[2]);
    }

    void refresh() {
        boolean pl = PlayerCore.playing();
        int a = PlayerCore.accent();
        cover.set(PlayerCore.cover, pl, a);
        prev.set(pl, a); play.set(pl, a); next.set(pl, a); gear.set(pl, a);
        bv.playing = pl;
        name.setText(PlayerCore.title());
        String t = PlayerCore.sleepLeft();
        if (PlayerCore.mp != null) {
            try {
                seek.setMax(PlayerCore.mp.getDuration());
                seek.setProgress(PlayerCore.mp.getCurrentPosition());
                int sec = PlayerCore.mp.getCurrentPosition() / 1000;
                t = sec / 60 + ":" + String.format("%02d", sec % 60) + (t.isEmpty() ? "" : "   " + t);
            } catch (Exception ignored) {}
        }
        time.setText(t);
    }

    void showSettings() {
        String[] it = {"☰  গানের তালিকা", "⏰  স্লিপ টাইমার", "🎨  কাস্টমাইজ", "✖  বাবল বন্ধ করুন"};
        new AlertDialog.Builder(this).setTitle("সেটিং").setItems(it, (d, i) -> {
            if (i == 0) showList();
            else if (i == 1) showTimer();
            else if (i == 2) showCustom();
            else { stopService(new Intent(this, FloatService.class)); PlayerCore.pause(); }
        }).show();
    }

    void showList() {
        if (PlayerCore.titles.isEmpty()) return;
        new AlertDialog.Builder(this).setTitle("গানের তালিকা")
            .setItems(PlayerCore.titles.toArray(new String[0]), (d, i) -> PlayerCore.start(i)).show();
    }

    void showTimer() {
        final int[] mins = {5, 10, 15, 30, 45, 60, 90};
        String[] items = new String[mins.length + 2];
        for (int i = 0; i < mins.length; i++) items[i] = mins[i] + " মিনিট";
        items[mins.length] = "নিজে সময় লিখুন";
        items[mins.length + 1] = "টাইমার বাতিল";
        new AlertDialog.Builder(this).setTitle("স্লিপ টাইমার").setItems(items, (d, i) -> {
            if (i < mins.length) PlayerCore.setSleep(mins[i]);
            else if (i == mins.length) {
                EditText e = new EditText(this);
                e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
                e.setHint("মিনিট (যেমন 20)");
                new AlertDialog.Builder(this).setTitle("কত মিনিট?").setView(e)
                    .setPositiveButton("সেট", (dd, w) -> {
                        try { PlayerCore.setSleep(Integer.parseInt(e.getText().toString().trim())); }
                        catch (Exception ex) { Toast.makeText(this, "সঠিক সংখ্যা দিন", Toast.LENGTH_SHORT).show(); }
                    }).setNegativeButton("বাদ", null).show();
            } else PlayerCore.setSleep(0);
        }).show();
    }

    void showCustom() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(50, 30, 50, 10);
        Button th = new Button(this);
        th.setText("থিম বদলান");
        th.setOnClickListener(v -> {
            PlayerCore.sp.edit().putInt("theme", (PlayerCore.sp.getInt("theme", 0) + 1) % PlayerCore.THEMES.length).apply();
            applyCfg(); refresh();
        });
        l.addView(th);
        l.addView(slider("বাবলের সংখ্যা", "count", 5, 80, 30));
        l.addView(slider("গতি", "speed", 1, 10, 3));
        new AlertDialog.Builder(this).setTitle("কাস্টমাইজ").setView(l).setPositiveButton("ঠিক আছে", null).show();
    }

    View slider(String label, String key, int min, int max, int def) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this);
        t.setText(label);
        SeekBar s = new SeekBar(this);
        s.setMax(max - min);
        s.setProgress(PlayerCore.sp.getInt(key, def) - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int p, boolean u) {
                if (u) { PlayerCore.sp.edit().putInt(key, p + min).apply(); applyCfg(); }
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        l.addView(t); l.addView(s);
        return l;
    }
}
