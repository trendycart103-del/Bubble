package com.example.bubbleplayer;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.util.Random;

/** ব্যাকগ্রাউন্ড: গ্র্যাডিয়েন্ট + ভাসমান বুদবুদ (গভীরতা সহ) + ফাটলে কণা। */
public class BubbleView extends View {
    static final int MAXP = 120;
    float[] x, y, r, s, ph, depth;
    float[] px = new float[MAXP], py = new float[MAXP], pvx = new float[MAXP], pvy = new float[MAXP], pl = new float[MAXP];
    int count = 30, c1 = 0xFF0B1B2B, c2 = 0xFF1D4E6B, bc = 0xFF4FC3F7, c3 = 0xFF7C4DFF;
    float speed = 3;
    boolean playing;
    float beat;
    Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG), bg = new Paint(), glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    Random rnd = new Random();

    public BubbleView(Context c) {
        super(c);
        line.setStyle(Paint.Style.STROKE);
    }

    public void config(int count, float speed, int top, int bottom, int accent, int accent2) {
        this.count = count; this.speed = speed; this.c1 = top; this.c2 = bottom; this.bc = accent; this.c3 = accent2;
        rebuildBg();
        if (x == null || x.length != count) init();
    }

    void rebuildBg() {
        bg.setShader(new LinearGradient(0, 0, 0, Math.max(getHeight(), 1), c1, c2, Shader.TileMode.CLAMP));
        float w = Math.max(getWidth(), 1), h = Math.max(getHeight(), 1);
        glow.setShader(new RadialGradient(w * 0.5f, h * 0.38f, Math.max(w, h) * 0.6f,
            (bc & 0x00FFFFFF) | 0x38000000, 0x00000000, Shader.TileMode.CLAMP));
    }

    void init() {
        x = new float[count]; y = new float[count]; r = new float[count]; s = new float[count]; ph = new float[count]; depth = new float[count];
        for (int i = 0; i < count; i++) spawn(i, true);
    }

    void spawn(int i, boolean anywhere) {
        int w = getWidth() > 0 ? getWidth() : 1080, h = getHeight() > 0 ? getHeight() : 1920;
        depth[i] = 0.35f + rnd.nextFloat() * 0.65f;
        r[i] = (14 + rnd.nextFloat() * 62) * (0.6f + depth[i] * 0.6f);
        x[i] = rnd.nextFloat() * w;
        y[i] = anywhere ? rnd.nextFloat() * h : h + r[i];
        s[i] = (0.4f + rnd.nextFloat()) * (0.5f + depth[i]);
        ph[i] = rnd.nextFloat() * 6.28f;
    }

    void burst(float bx, float by) {
        int made = 0;
        for (int k = 0; k < MAXP && made < 14; k++) {
            if (pl[k] > 0) continue;
            double a = rnd.nextDouble() * Math.PI * 2; float v = 2 + rnd.nextFloat() * 5;
            px[k] = bx; py[k] = by; pvx[k] = (float) Math.cos(a) * v; pvy[k] = (float) Math.sin(a) * v; pl[k] = 1f;
            made++;
        }
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) { rebuildBg(); init(); }

    @Override protected void onDraw(Canvas c) {
        c.drawRect(0, 0, getWidth(), getHeight(), bg);
        c.drawRect(0, 0, getWidth(), getHeight(), glow);
        long now = System.currentTimeMillis();
        float target = playing ? 0.5f + 0.5f * (float) Math.sin(now / 230.0) : 0f;
        beat += (target - beat) * 0.12f;
        float pulse = 1 + 0.06f * beat;
        float mul = playing ? 1.7f : 1f;
        for (int i = 0; i < count; i++) {
            y[i] -= s[i] * speed * mul;
            x[i] += Math.sin(ph[i] + y[i] / 90) * 0.7f;
            if (y[i] < -r[i] * 2) spawn(i, false);
            float rr = r[i] * pulse, d = depth[i];
            int col = (i % 3 == 0) ? c3 : bc;
            fill.setColor(col); fill.setAlpha((int) (28 + 40 * d));
            c.drawCircle(x[i], y[i], rr, fill);
            line.setStrokeWidth(1.5f + 2.5f * d);
            line.setColor(col); line.setAlpha((int) (60 + 130 * d));
            c.drawCircle(x[i], y[i], rr, line);
            fill.setColor(Color.WHITE); fill.setAlpha((int) (50 + 110 * d));
            c.drawCircle(x[i] - rr * 0.35f, y[i] - rr * 0.35f, rr * 0.14f, fill);
        }
        for (int k = 0; k < MAXP; k++) {
            if (pl[k] <= 0) continue;
            px[k] += pvx[k]; py[k] += pvy[k]; pvy[k] += 0.15f; pl[k] -= 0.035f;
            fill.setColor(bc); fill.setAlpha((int) (Math.max(pl[k], 0) * 220));
            c.drawCircle(px[k], py[k], 4 + 4 * pl[k], fill);
        }
        postInvalidateOnAnimation();
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN && x != null) {
            for (int i = 0; i < count; i++) {
                float dx = e.getX() - x[i], dy = e.getY() - y[i];
                if (dx * dx + dy * dy < r[i] * r[i] * 1.2f) { burst(x[i], y[i]); spawn(i, false); }
            }
            return true;
        }
        return super.onTouchEvent(e);
    }
}
