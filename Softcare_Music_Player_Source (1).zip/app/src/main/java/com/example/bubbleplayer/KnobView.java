package com.example.bubbleplayer;

import android.content.Context;
import android.graphics.*;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

/** আঙুল দিয়ে ঘুরিয়ে (সোয়াইপ করে) চালানোর গোল নব। মান ০–১০০, ৫০ = স্বাভাবিক। */
public class KnobView extends View {
    interface Listener { void onChange(int value); }

    String label; int value = 50, color = 0xFF4FC3F7; boolean touching;
    Listener listener;
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    RectF rect = new RectF();
    float lastAngle;

    public KnobView(Context c, String label) {
        super(c);
        this.label = label;
    }

    void setColor(int c) { if (c != color) { color = c; invalidate(); } }
    void setValue(int v) { if (!touching && v != value) { value = v; invalidate(); } }

    float angleOf(MotionEvent e) {
        float cx = getWidth() / 2f, cy = getWidth() / 2f;
        return (float) Math.toDegrees(Math.atan2(e.getY() - cy, e.getX() - cx));
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float cx = getWidth() / 2f, cy = getWidth() / 2f;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touching = true;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                lastAngle = angleOf(e);
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dxp = e.getX() - cx, dyp = e.getY() - cy;
                if (dxp * dxp + dyp * dyp < 64f) return true; // একদম মাঝখানে অস্থির কোণ হয়, তাই বাদ
                float a = angleOf(e);
                float d = a - lastAngle;
                if (d > 180) d -= 360; else if (d < -180) d += 360;
                lastAngle = a;
                int nv = Math.max(0, Math.min(100, Math.round(value + d * (100f / 270f))));
                if (nv != value) {
                    value = nv; invalidate();
                    if (nv % 5 == 0) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                    if (listener != null) listener.onChange(nv);
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                touching = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                return true;
        }
        return super.onTouchEvent(e);
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2, cy = w / 2, R = w / 2 * 0.92f, sw = w * 0.07f;
        p.setShader(null); p.clearShadowLayer();
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setStrokeCap(Paint.Cap.ROUND);
        rect.set(cx - R + sw / 2, cy - R + sw / 2, cx + R - sw / 2, cy + R - sw / 2);
        p.setColor(0x33FFFFFF);
        c.drawArc(rect, 135, 270, false, p);
        p.setColor(color);
        p.setShadowLayer(sw * 1.2f, 0, 0, color);
        if (value > 0) c.drawArc(rect, 135, 270f * value / 100f, false, p);
        p.clearShadowLayer();

        float br = R * 0.68f;
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx - br / 3, cy - br / 3, br * 1.5f, 0xFF4A5566, 0xFF11151B, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, br, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w * 0.02f); p.setColor(0x66FFFFFF);
        c.drawCircle(cx, cy, br, p);

        double ang = Math.toRadians(135 + 270.0 * value / 100.0);
        p.setStrokeWidth(sw * 0.8f); p.setColor(Color.WHITE);
        c.drawLine(cx + (float) Math.cos(ang) * br * 0.35f, cy + (float) Math.sin(ang) * br * 0.35f,
                   cx + (float) Math.cos(ang) * br * 0.82f, cy + (float) Math.sin(ang) * br * 0.82f, p);

        p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(w * 0.19f); p.setColor(0xDDFFFFFF);
        c.drawText(label + " " + value, cx, w + (h - w) * 0.72f, p);
    }
}
