package com.example.bubbleplayer;

import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.media.*;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

/** সব প্লেব্যাক লজিক এখানে: তালিকা, ফোল্ডার, পছন্দ, শাফল, রিপিট, অডিও ফোকাস, মিডিয়া সেশন, স্লিপ টাইমার। */
public class PlayerCore {
    // থিম: {ব্যাকগ্রাউন্ড ওপর, ব্যাকগ্রাউন্ড নিচ, অ্যাকসেন্ট, দ্বিতীয় অ্যাকসেন্ট}
    static final int[][] THEMES = {
        {0xFF0B1B2B, 0xFF1D4E6B, 0xFF4FC3F7, 0xFF7C4DFF},  // ওশান
        {0xFF2B1055, 0xFF7597DE, 0xFFFFAF7B, 0xFFD76D77},  // সানসেট
        {0xFF000000, 0xFF111111, 0xFFFFFFFF, 0xFF888888},  // AMOLED
        {0xFF0F2D2A, 0xFF1F7A5C, 0xFFB9FBC0, 0xFF00E5A8},  // অরোরা
        {0xFF1A0033, 0xFF3D0F63, 0xFFFF4DFF, 0xFF00F0FF},  // সাইবার নিয়ন
        {0xFF3B0A1E, 0xFF8E2C57, 0xFFF48FB1, 0xFFFFD54F}}; // রোজ

    static final int REPEAT_OFF = 0, REPEAT_ALL = 1, REPEAT_ONE = 2;
    static final long ACTIONS = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
        | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS
        | PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_STOP;

    static Context ctx; static SharedPreferences sp; static Handler h;
    static MediaPlayer mp; static int idx = -1; static Bitmap cover;
    static int coverColor = 0; // কভার থেকে পাওয়া রং (0 = নেই)
    static long sleepEnd; static boolean shuffle; static int repeat;
    static boolean ready; // মিডিয়া প্লেয়ার প্রস্তুত কিনা
    static AudioManager am; static AudioFocusRequest focusReq; static boolean resumeOnFocus;
    static final Random rnd = new Random();

    static ArrayList<String> titles = new ArrayList<>();
    static ArrayList<String> artists = new ArrayList<>();
    static ArrayList<Uri> uris = new ArrayList<>();
    static ArrayList<String> folderOf = new ArrayList<>(); // প্রতিটি গানের ফোল্ডারের পথ
    static ArrayList<String> dirs = new ArrayList<>();     // আলাদা আলাদা ফোল্ডারের তালিকা
    static ArrayList<Integer> queue = new ArrayList<>();   // এখন যে তালিকা থেকে চলছে (সব / ফোল্ডার / পছন্দের)
    static ArrayList<Runnable> ls = new ArrayList<>();

    static int resumePos;            // গান শুরুর সময় এই মিলিসেকেন্ড থেকে চালাবে
    static boolean loading, playWhenLoaded;
    static MediaSession session; static long sessKey; static boolean sessForce;
    static int saveCnt;

    static void init(Context c) {
        if (ctx != null) return;
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences("cfg", 0);
        h = new Handler(Looper.getMainLooper());
        am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        shuffle = sp.getBoolean("shuffle", false);
        repeat = sp.getInt("repeat", REPEAT_ALL);
        initSession();
        // হেডফোন খুলে ফেললে গান থামবে
        BroadcastReceiver noisy = new BroadcastReceiver() {
            @Override public void onReceive(Context cc, Intent in) { pause(); }
        };
        IntentFilter nf = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(noisy, nf, Context.RECEIVER_NOT_EXPORTED);
        else ctx.registerReceiver(noisy, nf);
        tick();
    }

    // ---------- মিডিয়া সেশন (লক স্ক্রিন / ব্লুটুথ / হেডসেট বোতাম) ----------
    static void initSession() {
        session = new MediaSession(ctx, "BubblePlayer");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { if (!playing()) toggle(); }
            @Override public void onPause() { pause(); }
            @Override public void onSkipToNext() { step(1); }
            @Override public void onSkipToPrevious() { step(-1); }
            @Override public void onSeekTo(long p) { seek((int) p); }
            @Override public void onStop() { pause(); }
        });
        session.setActive(true);
    }

    static void syncSession() {
        if (session == null) return;
        boolean pl = playing();
        long key = (pl ? 1 : 0) + idx * 2L + 7919L * System.identityHashCode(cover) + (ready ? 100000007L : 0L);
        if (key == sessKey && !sessForce) return;
        sessKey = key; sessForce = false;
        MediaMetadata.Builder mb = new MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, title())
            .putString(MediaMetadata.METADATA_KEY_ARTIST, artist())
            .putLong(MediaMetadata.METADATA_KEY_DURATION, dur());
        if (cover != null) mb.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, cover);
        session.setMetadata(mb.build());
        session.setPlaybackState(new PlaybackState.Builder()
            .setActions(ACTIONS)
            .setState(pl ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, pos(), pl ? 1f : 0f)
            .build());
    }

    // ---------- রং ----------
    static int[] theme() { return THEMES[sp.getInt("theme", 0)]; }
    static boolean dynamic() { return sp.getBoolean("dynamic", true); }
    static int accent() { return dynamic() && coverColor != 0 ? coverColor : theme()[2]; }
    static int accent2() { return theme()[3]; }
    static int bgTop() { return dynamic() && coverColor != 0 ? mix(coverColor, 0xFF000000, 0.78f) : theme()[0]; }
    static int bgBottom() { return dynamic() && coverColor != 0 ? mix(coverColor, 0xFF000000, 0.45f) : theme()[1]; }

    static int mix(int a, int b, float t) {
        int r = (int) (Color.red(a) * (1 - t) + Color.red(b) * t);
        int g = (int) (Color.green(a) * (1 - t) + Color.green(b) * t);
        int bl = (int) (Color.blue(a) * (1 - t) + Color.blue(b) * t);
        return Color.rgb(r, g, bl);
    }

    /** কভারের ছোট কপি থেকে সবচেয়ে উজ্জ্বল/রঙিন রং খুঁজে বের করে। */
    static int dominant(Bitmap b) {
        Bitmap s = Bitmap.createScaledBitmap(b, 24, 24, true);
        float best = -1; int bestC = 0;
        float[] hsv = new float[3];
        for (int y = 0; y < 24; y++) for (int x = 0; x < 24; x++) {
            int c = s.getPixel(x, y);
            Color.colorToHSV(c, hsv);
            float score = hsv[1] * hsv[2] + (hsv[2] > 0.35f ? 0.15f : 0);
            if (score > best) { best = score; bestC = c; }
        }
        Color.colorToHSV(bestC, hsv);
        hsv[1] = Math.max(hsv[1], 0.45f); hsv[2] = Math.max(hsv[2], 0.85f);
        return Color.HSVToColor(hsv);
    }

    // ---------- তথ্য ----------
    static boolean playing() { try { return ready && mp != null && mp.isPlaying(); } catch (Exception e) { return false; } }
    static String title() { return idx >= 0 && idx < titles.size() ? titles.get(idx) : "গান বেছে নিন"; }
    static String artist() { return idx >= 0 && idx < artists.size() ? artists.get(idx) : "বাবল প্লেয়ার"; }
    static int pos() { try { return ready && mp != null ? mp.getCurrentPosition() : 0; } catch (Exception e) { return 0; } }
    static int dur() { try { return ready && mp != null ? mp.getDuration() : 0; } catch (Exception e) { return 0; } }
    static String fmt(int ms) { int s = ms / 1000; return s / 60 + ":" + String.format("%02d", s % 60); }
    static String dirName(String path) { int s = path.lastIndexOf('/'); return s >= 0 ? path.substring(s + 1) : path; }

    // ---------- পছন্দের গান ----------
    static String favKey(int i) { return String.valueOf(ContentUris.parseId(uris.get(i))); }
    static boolean isFav(int i) {
        if (i < 0 || i >= uris.size()) return false;
        return sp.getStringSet("fav", new HashSet<String>()).contains(favKey(i));
    }
    static boolean toggleFav(int i) {
        if (i < 0 || i >= uris.size()) return false;
        Set<String> s = new HashSet<>(sp.getStringSet("fav", new HashSet<String>()));
        String k = favKey(i);
        boolean has = s.contains(k);
        if (has) s.remove(k); else s.add(k);
        sp.edit().putStringSet("fav", s).apply();
        return !has;
    }

    // ---------- তালিকা ----------
    static void load() {
        if (loading) return;
        loading = true;
        new Thread(() -> {
            ArrayList<String> t = new ArrayList<>(), a = new ArrayList<>(), f = new ArrayList<>();
            ArrayList<Uri> u = new ArrayList<>();
            try (Cursor c = ctx.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                        MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DATA},
                    MediaStore.Audio.Media.IS_MUSIC + "!=0", null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE")) {
                while (c != null && c.moveToNext()) {
                    u.add(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(0)));
                    String ti = c.getString(1);
                    t.add(ti == null ? "?" : ti);
                    String ar = c.getString(2);
                    a.add(ar == null || ar.contains("unknown") ? "অজানা শিল্পী" : ar);
                    String d = c.getString(3);
                    int sl = d == null ? -1 : d.lastIndexOf('/');
                    f.add(sl > 0 ? d.substring(0, sl) : "");
                }
            } catch (Exception ignored) {}
            TreeSet<String> ds = new TreeSet<>(f);
            ds.remove("");
            ArrayList<String> dl = new ArrayList<>(ds);
            h.post(() -> { loading = false; applyList(t, a, u, f, dl); });
        }).start();
    }

    static void applyList(ArrayList<String> t, ArrayList<String> a, ArrayList<Uri> u, ArrayList<String> f, ArrayList<String> ds) {
        long cur = (idx >= 0 && idx < uris.size()) ? ContentUris.parseId(uris.get(idx)) : sp.getLong("lastId", -1);
        boolean live = mp != null;
        titles = t; artists = a; uris = u; folderOf = f; dirs = ds;
        idx = -1;
        for (int i = 0; i < u.size(); i++) if (ContentUris.parseId(u.get(i)) == cur) { idx = i; break; }
        if (idx >= 0 && !live) resumePos = sp.getInt("lastPos", 0); // শেষ গান আর অবস্থান মনে রাখা
        queue = new ArrayList<>();
        for (int i = 0; i < u.size(); i++) queue.add(i);
        if (playWhenLoaded) {
            playWhenLoaded = false;
            if (!u.isEmpty()) start(idx >= 0 ? idx : 0);
        }
        fire();
    }

    // ---------- অডিও ফোকাস ----------
    static AudioManager.OnAudioFocusChangeListener focusL = ch -> {
        if (ch == AudioManager.AUDIOFOCUS_LOSS) { resumeOnFocus = false; pause(); }
        else if (ch == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) { resumeOnFocus = playing(); pause(); }
        else if (ch == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) { if (mp != null && ready) mp.setVolume(0.25f, 0.25f); }
        else if (ch == AudioManager.AUDIOFOCUS_GAIN) {
            if (mp != null && ready) mp.setVolume(1f, 1f);
            if (resumeOnFocus && mp != null && ready) { mp.start(); resumeOnFocus = false; fire(); }
        }
    };

    static boolean requestFocus() {
        if (Build.VERSION.SDK_INT >= 26) {
            if (focusReq == null) focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setOnAudioFocusChangeListener(focusL).build();
            return am.requestAudioFocus(focusReq) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        }
        return am.requestAudioFocus(focusL, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    }

    // ---------- প্লে ----------
    /** আজানের সময় হলে true, সাথে বার্তা দেখায়। */
    static boolean azanBlock() {
        String w = AzanGuard.blockedNow();
        if (w == null) return false;
        Toast.makeText(ctx, "🕌 " + w + "র আজানের সময়, আরও " + AzanGuard.minutesLeft() + " মিনিট গান চালানো যাবে না", Toast.LENGTH_LONG).show();
        return true;
    }

    static void start(int i) {
        if (uris.isEmpty() || i < 0 || i >= uris.size()) return;
        if (azanBlock()) return;
        try {
            if (mp != null) { mp.release(); mp = null; }
            ready = false; idx = i;
            final int rp = resumePos; resumePos = 0;
            sp.edit().putLong("lastId", ContentUris.parseId(uris.get(i))).putInt("lastPos", rp).apply();
            requestFocus();
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mp.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK);
            mp.setDataSource(ctx, uris.get(i));
            mp.setOnPreparedListener(m -> { ready = true; if (rp > 0) m.seekTo(rp); m.start(); sessForce = true; fire(); });
            mp.setOnCompletionListener(m -> onEnd());
            mp.setOnErrorListener((m, w, e) -> { ready = false; Toast.makeText(ctx, "চালানো যায়নি", Toast.LENGTH_SHORT).show(); fire(); return true; });
            mp.prepareAsync();
            final Uri cu = uris.get(i); final int my = i;
            cover = null; coverColor = 0;
            new Thread(() -> {
                Bitmap bm = null; int col = 0;
                MediaMetadataRetriever r = new MediaMetadataRetriever();
                try {
                    r.setDataSource(ctx, cu);
                    byte[] b = r.getEmbeddedPicture();
                    if (b != null) {
                        BitmapFactory.Options o = new BitmapFactory.Options(); o.inSampleSize = 2;
                        bm = BitmapFactory.decodeByteArray(b, 0, b.length, o);
                        if (bm != null) col = dominant(bm);
                    }
                } catch (Exception ignored) {} finally { try { r.release(); } catch (Exception ignored) {} }
                final Bitmap fb = bm; final int fc = col;
                h.post(() -> { if (idx == my) { cover = fb; coverColor = fc; sessForce = true; fire(); } });
            }).start();
        } catch (Exception e) {
            Toast.makeText(ctx, "চালানো যায়নি", Toast.LENGTH_SHORT).show();
        }
        fire();
    }

    static void onEnd() {
        if (repeat == REPEAT_ONE) { resumePos = 0; start(idx); return; }
        if (repeat == REPEAT_OFF && !shuffle && queue.indexOf(idx) == queue.size() - 1) { fire(); return; }
        step(1);
    }

    /** d = +1 পরের, -1 আগের। শুধু বর্তমান তালিকা (queue) এর ভেতর ঘোরে। */
    static void step(int d) {
        if (uris.isEmpty()) return;
        if (queue.isEmpty()) for (int i = 0; i < uris.size(); i++) queue.add(i);
        int n = queue.size();
        resumePos = 0;
        if (shuffle && d > 0 && n > 1) {
            int x;
            do { x = queue.get(rnd.nextInt(n)); } while (x == idx);
            start(x);
            return;
        }
        int p = queue.indexOf(idx);
        if (p < 0) p = d > 0 ? -1 : 0;
        start(queue.get(((p + d) % n + n) % n));
    }

    static void toggle() {
        if (!playing() && azanBlock()) return;
        if (mp == null) {
            if (uris.isEmpty()) { if (loading) playWhenLoaded = true; return; }
            start(idx >= 0 && idx < uris.size() ? idx : 0);
            return;
        }
        if (!ready) return;
        if (playing()) { mp.pause(); savePos(); }
        else {
            requestFocus();
            if (dur() > 0 && pos() >= dur() - 500) mp.seekTo(0);
            mp.start();
        }
        sessForce = true;
        fire();
    }
    static void pause() { try { if (playing()) { mp.pause(); savePos(); } } catch (Exception ignored) {} sessForce = true; fire(); }
    static void seek(int p) { try { if (ready && mp != null) { mp.seekTo(p); sessForce = true; } } catch (Exception ignored) {} }
    static void savePos() { if (idx >= 0 && ready) sp.edit().putInt("lastPos", pos()).apply(); }

    static void toggleShuffle() { shuffle = !shuffle; sp.edit().putBoolean("shuffle", shuffle).apply(); fire(); }
    static void cycleRepeat() { repeat = (repeat + 1) % 3; sp.edit().putInt("repeat", repeat).apply(); fire(); }

    // ---------- স্লিপ টাইমার ----------
    static void setSleep(int min) {
        sleepEnd = min > 0 ? System.currentTimeMillis() + min * 60000L : 0;
        Toast.makeText(ctx, min > 0 ? min + " মিনিট পরে গান বন্ধ হবে" : "টাইমার বাতিল", Toast.LENGTH_SHORT).show();
    }
    static String sleepLeft() {
        if (sleepEnd <= 0) return "";
        long l = Math.max((sleepEnd - System.currentTimeMillis()) / 1000, 0);
        return "⏰ " + l / 60 + ":" + String.format("%02d", l % 60);
    }

    static void fire() {
        syncSession();
        for (Runnable r : new ArrayList<>(ls)) r.run();
    }

    static void tick() {
        if (playing() && AzanGuard.blockedNow() != null) {
            pause();
            Toast.makeText(ctx, "🕌 আজানের সময় হয়েছে, গান থামানো হলো", Toast.LENGTH_LONG).show();
        }
        if (sleepEnd > 0 && System.currentTimeMillis() >= sleepEnd) {
            sleepEnd = 0; pause();
            Toast.makeText(ctx, "টাইমার শেষ, গান বন্ধ", Toast.LENGTH_LONG).show();
        }
        if (playing() && ++saveCnt % 10 == 0) savePos(); // প্রতি ৫ সেকেন্ডে অবস্থান সেভ
        fire();
        h.postDelayed(PlayerCore::tick, 500);
    }
}
