package com.example.bubbleplayer;

import java.util.Calendar;
import java.util.TimeZone;

/**
 * আজানের সময় গণনা। ইন্টারনেট লাগে না।
 * লোকেশন: ডিফল্টভাবে ফোনের GPS (শেষ জানা অবস্থান), নইলে হাতে বাছা জেলা (ডিফল্ট ঢাকা)।
 * পদ্ধতি: University of Islamic Sciences, Karachi (ফজর ১৮°, ইশা ১৮°), আসর হানাফি।
 * মসজিদের জামাতের সময়ের সাথে কয়েক মিনিট তফাত হতে পারে, তাই আগে/পরের সময় বদলানো যায়।
 */
public class AzanGuard {
    static final String[] DNAME = {
        "ঢাকা", "চট্টগ্রাম", "সিলেট", "রাজশাহী", "খুলনা", "বরিশাল", "রংপুর", "ময়মনসিংহ",
        "কুমিল্লা", "নারায়ণগঞ্জ", "গাজীপুর", "বগুড়া", "যশোর", "দিনাজপুর", "কক্সবাজার", "ফেনী",
        "নোয়াখালী", "টাঙ্গাইল", "ফরিদপুর", "পাবনা", "কুষ্টিয়া", "ব্রাহ্মণবাড়িয়া", "হবিগঞ্জ", "মৌলভীবাজার",
        "পটুয়াখালী", "নরসিংদী", "জামালপুর", "সাতক্ষীরা", "চাঁদপুর", "রাঙ্গামাটি", "বান্দরবান", "খাগড়াছড়ি",
        "কিশোরগঞ্জ", "লক্ষ্মীপুর", "নেত্রকোনা", "সিরাজগঞ্জ", "নওগাঁ", "ঠাকুরগাঁও", "কুড়িগ্রাম"};
    static final double[][] DLL = {
        {23.8103, 90.4125}, {22.3569, 91.7832}, {24.8949, 91.8687}, {24.3745, 88.6042}, {22.8456, 89.5403},
        {22.7010, 90.3535}, {25.7439, 89.2752}, {24.7471, 90.4203}, {23.4607, 91.1809}, {23.6238, 90.5000},
        {23.9999, 90.4203}, {24.8465, 89.3773}, {23.1664, 89.2081}, {25.6279, 88.6332}, {21.4272, 92.0058},
        {23.0159, 91.3976}, {22.8696, 91.0995}, {24.2513, 89.9167}, {23.6070, 89.8429}, {24.0064, 89.2372},
        {23.9013, 89.1205}, {23.9571, 91.1119}, {24.3745, 91.4155}, {24.4829, 91.7774}, {22.3596, 90.3299},
        {23.9322, 90.7151}, {24.9375, 89.9372}, {22.7185, 89.0705}, {23.2333, 90.6713}, {22.6372, 92.2013},
        {22.1953, 92.2184}, {23.1193, 91.9847}, {24.4449, 90.7766}, {22.9425, 90.8412}, {24.8700, 90.7279},
        {24.4534, 89.7007}, {24.8137, 88.9318}, {26.0337, 88.4617}, {25.8054, 89.6361}};

    static final TimeZone BD = TimeZone.getTimeZone("GMT+06:00");
    static final String[] NAMES = {"ফজর", "যোহর", "আসর", "মাগরিব", "ইশা"};

    static int before() { return PlayerCore.sp.getInt("azan_before", 5); }
    static int after() { return PlayerCore.sp.getInt("azan_after", 5); }
    static boolean enabled() { return PlayerCore.sp.getBoolean("azan_on", true); }

    // ---------- লোকেশন ----------
    static double lat() { return PlayerCore.sp.getFloat("lat", 23.8103f); }
    static double lon() { return PlayerCore.sp.getFloat("lon", 90.4125f); }
    /** true হলে GPS মোড (ডিফল্ট)। */
    static boolean gps() { return PlayerCore.sp.getBoolean("locgps", true); }
    static String locName() { return PlayerCore.sp.getString("locname", gps() ? "GPS (এখনো পাওয়া যায়নি, ঢাকা ধরা হচ্ছে)" : "ঢাকা"); }
    static TimeZone tz() { return gps() ? TimeZone.getDefault() : BD; }

    static void setLoc(double la, double lo, String name, boolean g) {
        PlayerCore.sp.edit().putFloat("lat", (float) la).putFloat("lon", (float) lo)
            .putString("locname", name).putBoolean("locgps", g).apply();
    }

    static double rad(double d) { return d * Math.PI / 180; }
    static double deg(double r) { return r * 180 / Math.PI; }

    /** আজকের পাঁচ ওয়াক্তের সময় (মিলিসেকেন্ডে)। */
    static long[] times(Calendar day) {
        TimeZone z = tz();
        double la = lat(), lo = lon();
        Calendar c = (Calendar) day.clone();
        c.setTimeZone(z);
        int y = c.get(Calendar.YEAR), m = c.get(Calendar.MONTH) + 1, d = c.get(Calendar.DAY_OF_MONTH);
        // জুলিয়ান দিন
        int a = (14 - m) / 12, yy = y + 4800 - a, mm = m + 12 * a - 3;
        double jd = d + (153 * mm + 2) / 5 + 365.0 * yy + yy / 4 - yy / 100 + yy / 400 - 32045 - 0.5;
        double n = jd - 2451545.0 + 0.5;
        double L = (280.460 + 0.9856474 * n) % 360;
        double g = rad((357.528 + 0.9856003 * n) % 360);
        double lam = rad(L + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g));
        double eps = rad(23.439 - 0.0000004 * n);
        double decl = Math.asin(Math.sin(eps) * Math.sin(lam));
        double ra = Math.atan2(Math.cos(eps) * Math.sin(lam), Math.cos(lam));
        double eqt = (L / 15.0) - (deg(ra) / 15.0);
        eqt = ((eqt + 12) % 24 + 24) % 24 - 12;

        Calendar base = Calendar.getInstance(z);
        base.setTimeInMillis(c.getTimeInMillis());
        base.set(Calendar.HOUR_OF_DAY, 0); base.set(Calendar.MINUTE, 0); base.set(Calendar.SECOND, 0); base.set(Calendar.MILLISECOND, 0);
        double off = z.getOffset(base.getTimeInMillis() + 12 * 3600000L) / 3600000.0;
        double noon = 12 + off - lo / 15.0 - eqt; // স্থানীয় ঘড়িতে দুপুর

        double fajr = noon - hourAngle(18, decl, la);
        double dhuhr = noon + 0.0333; // সূর্য ঢলার পর ২ মিনিট
        double asr = noon + asrAngle(2, decl, la);
        double maghrib = noon + hourAngle(0.833, decl, la) + 0.0167; // ১ মিনিট সতর্কতা
        double isha = noon + hourAngle(18, decl, la) + 0.0167; // ১ মিনিট সতর্কতা

        double[] hrs = {fajr, dhuhr, asr, maghrib, isha};
        long[] out = new long[5];
        for (int i = 0; i < 5; i++) out[i] = base.getTimeInMillis() + (long) (hrs[i] * 3600000L);
        return out;
    }

    static double hourAngle(double angle, double decl, double la) {
        double x = (-Math.sin(rad(angle)) - Math.sin(rad(la)) * Math.sin(decl)) / (Math.cos(rad(la)) * Math.cos(decl));
        return deg(Math.acos(Math.max(-1, Math.min(1, x)))) / 15.0;
    }

    static double asrAngle(double shadow, double decl, double la) {
        double a = Math.atan(1.0 / (shadow + Math.tan(Math.abs(rad(la) - decl))));
        double x = (Math.sin(a) - Math.sin(rad(la)) * Math.sin(decl)) / (Math.cos(rad(la)) * Math.cos(decl));
        return deg(Math.acos(Math.max(-1, Math.min(1, x)))) / 15.0;
    }

    /** এখন আজানের নিষিদ্ধ সময়ে আছি কিনা। থাকলে ওয়াক্তের নাম, নইলে null। */
    static String blockedNow() {
        if (!enabled()) return null;
        long now = System.currentTimeMillis();
        Calendar c = Calendar.getInstance(tz());
        c.setTimeInMillis(now);
        long[] t = times(c);
        for (int i = 0; i < 5; i++) {
            if (now >= t[i] - before() * 60000L && now <= t[i] + after() * 60000L) return NAMES[i];
        }
        return null;
    }

    /** কতক্ষণ পর নিষেধাজ্ঞা শেষ (মিনিট), বার্তার জন্য। */
    static int minutesLeft() {
        long now = System.currentTimeMillis();
        Calendar c = Calendar.getInstance(tz()); c.setTimeInMillis(now);
        long[] t = times(c);
        for (int i = 0; i < 5; i++) {
            long end = t[i] + after() * 60000L;
            if (now >= t[i] - before() * 60000L && now <= end) return (int) Math.max(1, (end - now) / 60000L + 1);
        }
        return 0;
    }
}
