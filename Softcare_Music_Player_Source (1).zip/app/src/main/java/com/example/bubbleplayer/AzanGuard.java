package com.example.bubbleplayer;

import java.util.Calendar;
import java.util.TimeZone;

/**
 * আজানের সময় (স্থির)। ইন্টারনেট বা লোকেশন লাগে না।
 * শুধু দুই ওয়াক্ত: যোহর ১:১০ এবং আসর ৪:১৫ (বাংলাদেশ সময়)।
 * প্রতিটির ৫ মিনিট আগে থেকে ৫ মিনিট পর পর্যন্ত প্লেয়ার বন্ধ থাকে।
 */
public class AzanGuard {
    static final TimeZone BD = TimeZone.getTimeZone("GMT+06:00");
    static final String[] NAMES = {"Zuhr", "Asr"};
    // দিনের শুরু থেকে মিনিটে: ১:১০ = ৭০, ৪:১৫ = ২৫৫ (দুপুর/বিকাল, ২৪ ঘণ্টার হিসাবে ১৩:১০ ও ১৬:১৫)
    static final int[] AZAN_MIN = {13 * 60 + 10, 16 * 60 + 15};
    static final int WINDOW = 5; // মিনিট, আগে ও পরে

    static int minuteOfDay(long now) {
        Calendar c = Calendar.getInstance(BD);
        c.setTimeInMillis(now);
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
    }

    /** এখন আজানের নিষিদ্ধ সময়ে আছি কিনা। থাকলে ওয়াক্তের নাম, নইলে null। */
    static String blockedNow() {
        int m = minuteOfDay(System.currentTimeMillis());
        for (int i = 0; i < AZAN_MIN.length; i++) {
            if (m >= AZAN_MIN[i] - WINDOW && m <= AZAN_MIN[i] + WINDOW) return NAMES[i];
        }
        return null;
    }

    /** নিষেধাজ্ঞা শেষ হতে আর কত মিনিট, বার্তার জন্য। */
    static int minutesLeft() {
        long now = System.currentTimeMillis();
        Calendar c = Calendar.getInstance(BD);
        c.setTimeInMillis(now);
        int m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
        for (int i = 0; i < AZAN_MIN.length; i++) {
            int end = AZAN_MIN[i] + WINDOW;
            if (m >= AZAN_MIN[i] - WINDOW && m <= end) return Math.max(1, end - m + 1);
        }
        return 0;
    }
}
