package com.example.bubbleplayer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import java.util.ArrayList;

public class MainActivity extends Activity {
    FrameLayout azanOverlay; TextView azanBig, azanSub; BubbleView bv; CoverView cover; TextView name, artist, time, total, azanBadge; SeekBar seek;
    IconButton prev, play, next, gear, shuf, rep, list;
    boolean askedOverlay, dragging;
    Runnable ui = this::refresh;
    int lastBg;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        PlayerCore.init(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        FrameLayout root = new FrameLayout(this);
        bv = new BubbleView(this);
        root.addView(bv);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(24), dp(48), dp(24), dp(40));

        // আজান ব্যাজ (ওপরে)
        azanBadge = new TextView(this);
        azanBadge.setTextColor(Color.WHITE); azanBadge.setTextSize(13); azanBadge.setGravity(Gravity.CENTER);
        azanBadge.setPadding(dp(14), dp(6), dp(14), dp(6));
        azanBadge.setVisibility(View.INVISIBLE);
        col.addView(azanBadge, new LinearLayout.LayoutParams(-2, -2));

        col.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1));
        cover = new CoverView(this);
        col.addView(cover, new LinearLayout.LayoutParams(dp(280), dp(280)));

        name = new TextView(this);
        name.setTextColor(0xFFFFFFFF); name.setTextSize(24); name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setGravity(Gravity.CENTER); name.setPadding(0, dp(22), 0, dp(2)); name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.MARQUEE); name.setSelected(true); name.setMarqueeRepeatLimit(-1);
        col.addView(name, new LinearLayout.LayoutParams(-1, -2));
        artist = new TextView(this);
        artist.setTextColor(0xB3FFFFFF); artist.setTextSize(15); artist.setGravity(Gravity.CENTER); artist.setSingleLine(true);
        col.addView(artist, new LinearLayout.LayoutParams(-1, -2));
        col.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1));

        // গ্লাস কন্ট্রোল কার্ড
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(14), dp(18), dp(16));
        GradientDrawable cg = new GradientDrawable();
        cg.setColor(0x26FFFFFF); cg.setCornerRadius(dp(32)); cg.setStroke(dp(1), 0x44FFFFFF);
        card.setBackground(cg);

        seek = new SeekBar(this);
        card.addView(seek, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout times = new LinearLayout(this);
        time = new TextView(this); total = new TextView(this);
        time.setTextColor(0xCCFFFFFF); total.setTextColor(0xCCFFFFFF); time.setTextSize(12); total.setTextSize(12);
        total.setGravity(Gravity.END);
        times.addView(time, new LinearLayout.LayoutParams(0, -2, 1));
        times.addView(total, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(times, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        shuf = new IconButton(this, 4).small(); rep = new IconButton(this, 5).small();
        prev = new IconButton(this, 0); play = new IconButton(this, 1); next = new IconButton(this, 2);
        shuf.setOnClickListener(v -> PlayerCore.toggleShuffle());
        rep.setOnClickListener(v -> PlayerCore.cycleRepeat());
        prev.setOnClickListener(v -> PlayerCore.step(-1));
        play.setOnClickListener(v -> PlayerCore.toggle());
        next.setOnClickListener(v -> PlayerCore.step(1));
        row.addView(shuf, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout.LayoutParams s = new LinearLayout.LayoutParams(dp(66), dp(66)); s.setMargins(dp(6), 0, dp(6), 0);
        LinearLayout.LayoutParams L = new LinearLayout.LayoutParams(dp(90), dp(90)); L.setMargins(dp(6), 0, dp(6), 0);
        row.addView(prev, s); row.addView(play, L); row.addView(next, new LinearLayout.LayoutParams(s));
        row.addView(rep, new LinearLayout.LayoutParams(dp(44), dp(44)));
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));
        col.addView(card, new LinearLayout.LayoutParams(-1, -2));
        root.addView(col);

        // ওপরের কোণের বোতাম: তালিকা ও সেটিং
        list = new IconButton(this, 6).small();
        list.setOnClickListener(v -> showList());
        FrameLayout.LayoutParams lg = new FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP | Gravity.START);
        lg.setMargins(dp(20), dp(44), 0, 0);
        root.addView(list, lg);
        gear = new IconButton(this, 3).small();
        gear.setOnClickListener(v -> showSettings());
        FrameLayout.LayoutParams g = new FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP | Gravity.END);
        g.setMargins(0, dp(44), dp(20), 0);
        root.addView(gear, g);

        // ফুল স্ক্রিন আজান ওভারলে
        azanOverlay = new FrameLayout(this);
        azanOverlay.setBackgroundColor(0xF2000000);
        azanOverlay.setVisibility(View.GONE);
        azanOverlay.setClickable(true); // নিচের বোতামে টাচ আটকাবে
        LinearLayout ac = new LinearLayout(this);
        ac.setOrientation(LinearLayout.VERTICAL);
        ac.setGravity(Gravity.CENTER);
        azanBig = new TextView(this);
        azanBig.setText("আজান টাইম");
        azanBig.setTextColor(Color.WHITE); azanBig.setTextSize(64); azanBig.setTypeface(Typeface.DEFAULT_BOLD);
        azanBig.setGravity(Gravity.CENTER);
        azanBig.setShadowLayer(40, 0, 0, 0xFF00E5A8);
        ac.addView(azanBig, new LinearLayout.LayoutParams(-1, -2));
        azanSub = new TextView(this);
        azanSub.setTextColor(0xAAFFFFFF); azanSub.setTextSize(16); azanSub.setGravity(Gravity.CENTER);
        azanSub.setPadding(dp(24), dp(20), dp(24), 0);
        ac.addView(azanSub, new LinearLayout.LayoutParams(-1, -2));
        azanOverlay.addView(ac, new FrameLayout.LayoutParams(-1, -1));
        root.addView(azanOverlay, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int p, boolean u) { if (u) PlayerCore.seek(p); }
            public void onStartTrackingTouch(SeekBar sb) { dragging = true; }
            public void onStopTrackingTouch(SeekBar sb) { dragging = false; }
        });

        String perm = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(perm) == 0) PlayerCore.load();
        else if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{perm, Manifest.permission.POST_NOTIFICATIONS}, 1);
        else requestPermissions(new String[]{perm}, 1);
        applyCfg();
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        if (code == 2) {
            if (r.length > 0 && r[0] == 0) updateGps(true);
            else Toast.makeText(this, "লোকেশনের অনুমতি পাওয়া যায়নি, আজানের জন্য ঢাকা ধরা হচ্ছে (সেটিং থেকে জেলা বাছুন)", Toast.LENGTH_LONG).show();
            return;
        }
        if (r.length > 0 && r[0] == 0) { PlayerCore.load(); if (AzanGuard.gps()) updateGps(false); }
        else Toast.makeText(this, "গান পড়তে অনুমতি দরকার", Toast.LENGTH_LONG).show();
    }

    boolean hasAudioPerm() {
        String perm = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
        return checkSelfPermission(perm) == 0;
    }

    @Override protected void onStart() { super.onStart(); PlayerCore.ls.add(ui); refresh(); }
    @Override protected void onStop() { super.onStop(); PlayerCore.ls.remove(ui); }

    @Override protected void onResume() {
        super.onResume();
        // গান চালানোর সার্ভিস সবসময় চালু থাকবে, ওভারলে পারমিশন ছাড়াও
        startForegroundService(new Intent(this, FloatService.class));
        if (!Settings.canDrawOverlays(this) && !askedOverlay && !PlayerCore.sp.getBoolean("askedOv", false)) {
            askedOverlay = true;
            PlayerCore.sp.edit().putBoolean("askedOv", true).apply();
            Toast.makeText(this, "ভাসমান বাবল চাইলে অনুমতি চালু করুন (না দিলেও গান চলবে)", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        }
        if (AzanGuard.gps()) updateGps(false);
    }

    void applyCfg() {
        bv.config(PlayerCore.sp.getInt("count", 30), PlayerCore.sp.getInt("speed", 3),
            PlayerCore.bgTop(), PlayerCore.bgBottom(), PlayerCore.accent(), PlayerCore.accent2());
    }

    void refresh() {
        boolean pl = PlayerCore.playing();
        int a = PlayerCore.accent();
        // গানের রং বদলালে ব্যাকগ্রাউন্ডও বদলাবে
        int key = PlayerCore.bgTop() ^ PlayerCore.bgBottom() ^ a;
        if (key != lastBg) { lastBg = key; applyCfg(); }
        cover.set(PlayerCore.cover, pl, a);
        prev.set(pl, a); play.set(pl, a); next.set(pl, a); gear.set(pl, a);
        shuf.set(pl, a); shuf.setActive(PlayerCore.shuffle, false);
        rep.set(pl, a); rep.setActive(PlayerCore.repeat != PlayerCore.REPEAT_OFF, PlayerCore.repeat == PlayerCore.REPEAT_ONE);
        list.set(pl, a);
        bv.playing = pl;
        name.setText(PlayerCore.title());
        artist.setText(PlayerCore.artist());
        int d = PlayerCore.dur();
        if (!dragging && d > 0) { seek.setMax(d); seek.setProgress(PlayerCore.pos()); }
        String sl = PlayerCore.sleepLeft();
        time.setText(PlayerCore.fmt(PlayerCore.pos()) + (sl.isEmpty() ? "" : "   " + sl));
        total.setText(PlayerCore.fmt(d));
        // আজান ব্যাজ
        String w = AzanGuard.blockedNow();
        if (w != null) {
            azanBadge.setText("🕌 " + w + "র আজানের সময়, " + AzanGuard.minutesLeft() + " মিনিট পর গান চলবে");
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xCC1B5E20); bg.setCornerRadius(dp(20)); azanBadge.setBackground(bg);
            azanBadge.setVisibility(View.VISIBLE);
        } else azanBadge.setVisibility(View.INVISIBLE);
        // ফুল স্ক্রিন "আজান টাইম"
        if (w != null) {
            azanSub.setText(w + "র আজান\n" + AzanGuard.minutesLeft() + " মিনিট পর গান চালানো যাবে");
            if (azanOverlay.getVisibility() != View.VISIBLE) {
                azanOverlay.setAlpha(0f); azanOverlay.setVisibility(View.VISIBLE);
                azanOverlay.animate().alpha(1f).setDuration(400).start();
            }
        } else if (azanOverlay.getVisibility() == View.VISIBLE) {
            azanOverlay.animate().alpha(0f).setDuration(400).withEndAction(() -> azanOverlay.setVisibility(View.GONE)).start();
        }
    }

    // ------------------------------------------------------------------
    // গ্লাস স্টাইলের বটম শিট
    // ------------------------------------------------------------------
    Dialog sheet(String title, View content) {
        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(14), dp(20), dp(24));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xF2101820); g.setCornerRadii(new float[]{dp(30), dp(30), dp(30), dp(30), 0, 0, 0, 0});
        g.setStroke(dp(1), (PlayerCore.accent() & 0x00FFFFFF) | 0x55000000);
        box.setBackground(g);
        View handle = new View(this);
        GradientDrawable hg = new GradientDrawable(); hg.setColor(0x55FFFFFF); hg.setCornerRadius(dp(3));
        handle.setBackground(hg);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(dp(44), dp(5)); hp.gravity = Gravity.CENTER_HORIZONTAL;
        box.addView(handle, hp);
        TextView t = new TextView(this);
        t.setText(title); t.setTextColor(Color.WHITE); t.setTextSize(20); t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(14), 0, dp(10));
        box.addView(t);
        box.addView(content, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(box);
        Window w = d.getWindow();
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        w.setLayout(-1, -2);
        w.setGravity(Gravity.BOTTOM);
        w.setWindowAnimations(android.R.style.Animation_InputMethod);
        return d;
    }

    TextView row(String text, int color) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextColor(color); t.setTextSize(16);
        t.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable g = new GradientDrawable(); g.setColor(0x14FFFFFF); g.setCornerRadius(dp(16));
        t.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(4), 0, dp(4));
        t.setLayoutParams(lp);
        return t;
    }

    void showSettings() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        final Dialog[] dd = new Dialog[1];
        String[] items = {"⏰  স্লিপ টাইমার", "🎨  কাস্টমাইজ (থিম, বুদবুদ)", "🕌  আজান সেটিং",
            "🫧  ভাসমান বাবল চালু/অনুমতি", "✖  প্লেয়ার বন্ধ (নোটিফিকেশনসহ)"};
        for (int i = 0; i < items.length; i++) {
            final int k = i;
            TextView t = row(items[i], Color.WHITE);
            t.setOnClickListener(v -> {
                dd[0].dismiss();
                if (k == 0) showTimer();
                else if (k == 1) showCustom();
                else if (k == 2) showAzan();
                else if (k == 3) {
                    if (Settings.canDrawOverlays(this)) {
                        startForegroundService(new Intent(this, FloatService.class));
                        Toast.makeText(this, "বাবল চালু আছে", Toast.LENGTH_SHORT).show();
                    } else startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                } else { stopService(new Intent(this, FloatService.class)); PlayerCore.pause(); }
            });
            l.addView(t);
        }
        dd[0] = sheet("সেটিং", l); dd[0].show();
    }

    void styleChip(TextView c, boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(18));
        g.setColor(on ? ((PlayerCore.accent() & 0x00FFFFFF) | 0x66000000) : 0x1AFFFFFF);
        c.setBackground(g);
        c.setTextColor(Color.WHITE);
    }

    /** গানের তালিকা: সব / পছন্দের / ফোল্ডার অনুযায়ী। লং-প্রেস করলে পছন্দের তালিকায় যোগ/বাদ। */
    void showList() {
        if (PlayerCore.titles.isEmpty()) { Toast.makeText(this, "কোনো গান পাওয়া যায়নি", Toast.LENGTH_SHORT).show(); return; }
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        EditText q = new EditText(this);
        q.setHint("🔍  গান খুঁজুন"); q.setHintTextColor(0x88FFFFFF); q.setTextColor(Color.WHITE); q.setSingleLine(true);
        GradientDrawable qg = new GradientDrawable(); qg.setColor(0x1AFFFFFF); qg.setCornerRadius(dp(18)); q.setBackground(qg);
        q.setPadding(dp(16), dp(12), dp(16), dp(12));
        l.addView(q, new LinearLayout.LayoutParams(-1, -2));
        final String[] flt = {"all"};
        ScrollView sv = new ScrollView(this);
        LinearLayout items = new LinearLayout(this); items.setOrientation(LinearLayout.VERTICAL);
        sv.addView(items);
        l.addView(sv, new LinearLayout.LayoutParams(-1, (int) (getResources().getDisplayMetrics().heightPixels * 0.5f)));
        final Dialog[] dd = new Dialog[1];
        Runnable fill = () -> {
            items.removeAllViews();
            String f = q.getText().toString().trim().toLowerCase();
            final ArrayList<Integer> match = new ArrayList<>();
            for (int i = 0; i < PlayerCore.titles.size(); i++) {
                if (flt[0].equals("fav")) { if (!PlayerCore.isFav(i)) continue; }
                else if (!flt[0].equals("all") && !flt[0].equals(PlayerCore.folderOf.get(i))) continue;
                String ti = PlayerCore.titles.get(i), ar = PlayerCore.artists.get(i);
                if (!f.isEmpty() && !ti.toLowerCase().contains(f) && !ar.toLowerCase().contains(f)) continue;
                match.add(i);
            }
            if (match.isEmpty()) items.addView(row("কিছু পাওয়া যায়নি", 0x99FFFFFF));
            for (int k = 0; k < match.size() && k < 300; k++) {
                final int sidx = match.get(k);
                TextView t = row((PlayerCore.isFav(sidx) ? "❤ " : "") + PlayerCore.titles.get(sidx) + "\n" + PlayerCore.artists.get(sidx),
                    sidx == PlayerCore.idx ? PlayerCore.accent() : Color.WHITE);
                t.setSingleLine(false); t.setMaxLines(2); t.setEllipsize(TextUtils.TruncateAt.END);
                t.setOnClickListener(v -> {
                    PlayerCore.queue = new ArrayList<>(match); // এই তালিকাতেই আগের/পরের গান ঘুরবে
                    PlayerCore.resumePos = 0;
                    PlayerCore.start(sidx);
                    dd[0].dismiss();
                });
                t.setOnLongClickListener(v -> {
                    boolean on = PlayerCore.toggleFav(sidx);
                    Toast.makeText(this, on ? "❤ পছন্দের তালিকায় যোগ হলো" : "পছন্দের তালিকা থেকে সরানো হলো", Toast.LENGTH_SHORT).show();
                    t.setText((on ? "❤ " : "") + PlayerCore.titles.get(sidx) + "\n" + PlayerCore.artists.get(sidx));
                    return true;
                });
                items.addView(t);
            }
        };
        // ফোল্ডার/পছন্দের চিপ
        LinearLayout chipRow = new LinearLayout(this);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(chipRow);
        final ArrayList<TextView> chips = new ArrayList<>();
        final ArrayList<String> keys = new ArrayList<>();
        keys.add("all"); keys.add("fav"); keys.addAll(PlayerCore.dirs);
        for (int k = 0; k < keys.size(); k++) {
            final String key = keys.get(k);
            String lab = k == 0 ? "সব" : k == 1 ? "❤ পছন্দের" : "📁 " + PlayerCore.dirName(key);
            TextView chip = new TextView(this);
            chip.setText(lab); chip.setTextSize(14); chip.setSingleLine(true);
            chip.setPadding(dp(14), dp(8), dp(14), dp(8));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2); cp.setMargins(0, dp(8), dp(8), dp(4));
            chip.setOnClickListener(v -> {
                flt[0] = key;
                for (int j = 0; j < chips.size(); j++) styleChip(chips.get(j), keys.get(j).equals(flt[0]));
                fill.run();
            });
            chips.add(chip);
            chipRow.addView(chip, cp);
        }
        for (int j = 0; j < chips.size(); j++) styleChip(chips.get(j), j == 0);
        l.addView(hs, 1, new LinearLayout.LayoutParams(-1, -2));
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) { fill.run(); }
            public void afterTextChanged(Editable e) {}
        });
        fill.run();
        dd[0] = sheet("গানের তালিকা (" + PlayerCore.titles.size() + ")", l); dd[0].show();
    }

    void showTimer() {
        final int[] mins = {5, 10, 15, 30, 45, 60, 90};
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        final Dialog[] dd = new Dialog[1];
        for (int m : mins) {
            TextView t = row(m + " মিনিট", Color.WHITE);
            t.setOnClickListener(v -> { PlayerCore.setSleep(m); dd[0].dismiss(); });
            l.addView(t);
        }
        TextView own = row("নিজে সময় লিখুন", PlayerCore.accent());
        own.setOnClickListener(v -> {
            dd[0].dismiss();
            EditText e = new EditText(this);
            e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); e.setHint("মিনিট (যেমন 20)");
            new AlertDialog.Builder(this).setTitle("কত মিনিট?").setView(e)
                .setPositiveButton("সেট", (x, w) -> {
                    try { PlayerCore.setSleep(Integer.parseInt(e.getText().toString().trim())); }
                    catch (Exception ex) { Toast.makeText(this, "সঠিক সংখ্যা দিন", Toast.LENGTH_SHORT).show(); }
                }).setNegativeButton("বাদ", null).show();
        });
        l.addView(own);
        TextView off = row("টাইমার বাতিল", 0xFFFF8A80);
        off.setOnClickListener(v -> { PlayerCore.setSleep(0); dd[0].dismiss(); });
        l.addView(off);
        dd[0] = sheet("স্লিপ টাইমার", l); dd[0].show();
    }

    void showCustom() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        // থিম বাছাই: রঙিন গোল বোতাম
        TextView lab = new TextView(this); lab.setText("থিম"); lab.setTextColor(0xCCFFFFFF); lab.setPadding(0, 0, 0, dp(8));
        l.addView(lab);
        LinearLayout sw = new LinearLayout(this);
        for (int i = 0; i < PlayerCore.THEMES.length; i++) {
            final int k = i;
            View v = new View(this);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{PlayerCore.THEMES[i][1], PlayerCore.THEMES[i][2]});
            g.setShape(GradientDrawable.OVAL);
            g.setStroke(dp(PlayerCore.sp.getInt("theme", 0) == i ? 3 : 1), Color.WHITE);
            v.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44)); lp.setMargins(0, 0, dp(10), 0);
            v.setOnClickListener(x -> {
                PlayerCore.sp.edit().putInt("theme", k).apply();
                applyCfg(); refresh();
                for (int j = 0; j < sw.getChildCount(); j++) {
                    GradientDrawable gj = (GradientDrawable) sw.getChildAt(j).getBackground();
                    gj.setStroke(dp(j == k ? 3 : 1), Color.WHITE);
                }
            });
            sw.addView(v, lp);
        }
        l.addView(sw);
        // কভার থেকে রং চালু/বন্ধ
        CheckBox dyn = new CheckBox(this);
        dyn.setText("গানের কভার থেকে রং নিন"); dyn.setTextColor(Color.WHITE);
        dyn.setChecked(PlayerCore.dynamic());
        dyn.setOnCheckedChangeListener((b, c) -> { PlayerCore.sp.edit().putBoolean("dynamic", c).apply(); applyCfg(); refresh(); });
        dyn.setPadding(0, dp(12), 0, dp(4));
        l.addView(dyn);
        l.addView(slider("বুদবুদের সংখ্যা", "count", 5, 80, 30));
        l.addView(slider("গতি", "speed", 1, 10, 3));
        Dialog d = sheet("কাস্টমাইজ", l); d.show();
    }

    // ---------- লোকেশন (GPS / জেলা) ----------
    /** GPS মোডে ফোনের শেষ জানা অবস্থান নিয়ে আজানের সময় ঠিক করে। ask=true হলে অনুমতি চাইবে ও বার্তা দেখাবে। */
    void updateGps(boolean ask) {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != 0) {
            if (!ask && !hasAudioPerm()) return; // আগে গানের অনুমতির ডায়ালগ শেষ হোক
            if (ask || !PlayerCore.sp.getBoolean("askedLoc", false)) {
                PlayerCore.sp.edit().putBoolean("askedLoc", true).apply();
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 2);
            }
            return;
        }
        android.location.LocationManager lm = (android.location.LocationManager) getSystemService(LOCATION_SERVICE);
        android.location.Location best = null;
        try {
            for (String pv : lm.getProviders(true)) {
                try {
                    android.location.Location lo = lm.getLastKnownLocation(pv);
                    if (lo != null && (best == null || lo.getTime() > best.getTime())) best = lo;
                } catch (SecurityException ignored) {}
            }
        } catch (Exception ignored) {}
        if (best == null) {
            if (ask) Toast.makeText(this, "লোকেশন পাওয়া যায়নি। ফোনের লোকেশন চালু করে গুগল ম্যাপ একবার খুলে আবার চেষ্টা করুন", Toast.LENGTH_LONG).show();
            return;
        }
        AzanGuard.setLoc(best.getLatitude(), best.getLongitude(),
            "GPS (" + String.format(java.util.Locale.ENGLISH, "%.2f, %.2f", best.getLatitude(), best.getLongitude()) + ")", true);
        if (ask) Toast.makeText(this, "লোকেশন ধরা হয়েছে, আজানের সময় নতুন করে হিসাব হলো", Toast.LENGTH_LONG).show();
        refresh();
    }

    void showDistricts() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        LinearLayout items = new LinearLayout(this); items.setOrientation(LinearLayout.VERTICAL);
        sv.addView(items);
        l.addView(sv, new LinearLayout.LayoutParams(-1, (int) (getResources().getDisplayMetrics().heightPixels * 0.6f)));
        final Dialog[] dd = new Dialog[1];
        TextView g = row("📍 ফোনের GPS থেকে নিন (প্রস্তাবিত)", AzanGuard.gps() ? PlayerCore.accent() : Color.WHITE);
        g.setOnClickListener(v -> {
            dd[0].dismiss();
            PlayerCore.sp.edit().putBoolean("locgps", true).apply();
            updateGps(true);
        });
        items.addView(g);
        for (int i = 0; i < AzanGuard.DNAME.length; i++) {
            final int k = i;
            boolean cur = !AzanGuard.gps() && AzanGuard.DNAME[i].equals(AzanGuard.locName());
            TextView t = row("🏙  " + AzanGuard.DNAME[i], cur ? PlayerCore.accent() : Color.WHITE);
            t.setOnClickListener(v -> {
                AzanGuard.setLoc(AzanGuard.DLL[k][0], AzanGuard.DLL[k][1], AzanGuard.DNAME[k], false);
                dd[0].dismiss();
                Toast.makeText(this, AzanGuard.DNAME[k] + " অনুযায়ী আজানের সময় ঠিক হলো", Toast.LENGTH_SHORT).show();
                refresh();
            });
            items.addView(t);
        }
        dd[0] = sheet("এলাকা বেছে নিন", l); dd[0].show();
    }

    void showAzan() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        final Dialog[] dd = new Dialog[1];
        TextView loc = row("📍 এলাকা: " + AzanGuard.locName() + "  ›", PlayerCore.accent());
        loc.setOnClickListener(v -> { dd[0].dismiss(); showDistricts(); });
        l.addView(loc);
        CheckBox on = new CheckBox(this);
        on.setText("আজানের সময় গান বন্ধ রাখুন"); on.setTextColor(Color.WHITE);
        on.setChecked(AzanGuard.enabled());
        on.setOnCheckedChangeListener((b, c) -> { PlayerCore.sp.edit().putBoolean("azan_on", c).apply(); refresh(); });
        l.addView(on);
        l.addView(slider("আজানের আগে (মিনিট)", "azan_before", 0, 30, 5));
        l.addView(slider("আজানের পরে (মিনিট)", "azan_after", 0, 30, 5));
        // আজকের সময়সূচি
        java.util.Calendar c = java.util.Calendar.getInstance(AzanGuard.tz());
        long[] t = AzanGuard.times(c);
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("h:mm a", java.util.Locale.ENGLISH);
        f.setTimeZone(AzanGuard.tz());
        StringBuilder sb = new StringBuilder("আজকের সময়\n");
        for (int i = 0; i < 5; i++) sb.append(AzanGuard.NAMES[i]).append(": ").append(f.format(t[i])).append(i < 4 ? "\n" : "");
        TextView info = new TextView(this);
        info.setText(sb.toString()); info.setTextColor(0xCCFFFFFF); info.setTextSize(14); info.setPadding(0, dp(14), 0, 0);
        l.addView(info);
        TextView note = new TextView(this);
        note.setText("সময় গণনা করা (করাচি পদ্ধতি, আসর হানাফি)। মসজিদের জামাতের সময়ের সাথে কয়েক মিনিট তফাত হতে পারে, তাই প্রয়োজনে আগে/পরের মিনিট বাড়ান।");
        note.setTextColor(0x88FFFFFF); note.setTextSize(12); note.setPadding(0, dp(8), 0, 0);
        l.addView(note);
        dd[0] = sheet("আজান সেটিং", l); dd[0].show();
    }

    View slider(String label, String key, int min, int max, int def) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(0, dp(10), 0, 0);
        TextView t = new TextView(this);
        t.setTextColor(0xCCFFFFFF);
        int cur = PlayerCore.sp.getInt(key, def);
        t.setText(label + ": " + cur);
        SeekBar s = new SeekBar(this);
        s.setMax(max - min);
        s.setProgress(cur - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int p, boolean u) {
                if (u) { PlayerCore.sp.edit().putInt(key, p + min).apply(); t.setText(label + ": " + (p + min)); applyCfg(); }
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        l.addView(t); l.addView(s);
        return l;
    }
}
