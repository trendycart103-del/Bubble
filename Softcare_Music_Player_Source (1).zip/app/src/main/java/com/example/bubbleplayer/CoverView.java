package com.example.bubbleplayer;

import android.content.Context;
import android.graphics.*;
import android.view.View;

/**
 * ঘুরন্ত কভার (রেকর্ড) + কভারের ঠিক মাঝখানের দাগের ওপর ছন্দে নাচা ইকুয়ালাইজার।
 * দাগের ওপরে-নিচে সমান নাচে (আয়নার মতো), মাথায় ভেসে থাকা পিক ডট, নিচে ঝাপসা প্রতিফলন।
 * ভিজুয়ালাইজার সিনথেটিক: গানের অবস্থান (PlayerCore.pos) থেকে বিট ও ঢেউ হিসাব করে, কোনো অতিরিক্ত পারমিশন লাগে না।
 */
public class CoverView extends View {
    static final int NB = 21, NB_SMALL = 9;
    Bitmap bmp; boolean spin; int color = 0xFF4FC3F7; float ang;
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), ring = new Paint(Paint.ANTI_ALIAS_FLAG), groove = new Paint(Paint.ANTI_ALIAS_FLAG);
    Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG), glow = new Paint(Paint.ANTI_ALIAS_FLAG), dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    Paint dim = new Paint(Paint.ANTI_ALIAS_FLAG), axis = new Paint(Paint.ANTI_ALIAS_FLAG);
    Matrix m = new Matrix();
    float[] lv = new float[NB], pk = new float[NB], pkv = new float[NB];
    float level;
    BitmapShader shader; Bitmap shaderBmp;
    Shader glowShader; int glowColor, glowW = -1;
    Shader phShader; int phColor, phW = -1;
    RectF rf = new RectF();

    public CoverView(Context c) {
        super(c);
        ring.setStyle(Paint.Style.STROKE);
        groove.setStyle(Paint.Style.STROKE);
        bar.setStyle(Paint.Style.FILL);
        setClickable(false); setFocusable(false);
        dot.setStyle(Paint.Style.FILL);
        dot.setColor(Color.WHITE);
        dim.setStyle(Paint.Style.FILL);
        axis.setStyle(Paint.Style.STROKE);
        axis.setStrokeCap(Paint.Cap.ROUND);
    }

    void set(Bitmap b, boolean s, int col) {
        bmp = b; spin = s; color = col;
        if (s || level > 0.01f) postInvalidateOnAnimation(); else invalidate();
    }

    static float clamp(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

    @Override protected void onDraw(Canvas c) {
        try { draw2(c); } catch (Exception ex) { /* ড্রয়িং ভুল হলেও বাবল যেন কাজ করে */ }
    }

    void draw2(Canvas c) {
        float w = getWidth(), cx = w / 2, cy = getHeight() / 2;
        if (w <= 0) return;
        boolean small = w < 110 * getResources().getDisplayMetrics().density;
        int n = small ? NB_SMALL : NB, half = n / 2;
        float R0 = w * 0.44f;

        // ---- বিট ও লেভেল ----
        int posMs = 0;
        try { posMs = PlayerCore.pos(); } catch (Exception ignored) {}
        float t = posMs / 1000f;
        float bpm = 96 + (Math.abs(PlayerCore.idx * 37) % 48);
        float bph = (posMs * bpm / 60000f) % 1f;
        float e = (float) Math.pow(1f - bph, 3);
        float e2 = (float) Math.pow(1f - ((bph * 2f) % 1f), 4) * 0.5f;
        level += ((spin ? 1f : 0f) - level) * 0.08f;
        float beat = e * level;

        // ---- নরম গ্লো ----
        int gw = (int) w;
        if (glowShader == null || glowW != gw || glowColor != color) {
            glowW = gw; glowColor = color;
            glowShader = new RadialGradient(cx, cy, w * 0.5f, (color & 0x00FFFFFF) | 0xAA000000, 0x00000000, Shader.TileMode.CLAMP);
            glow.setShader(glowShader);
        }
        glow.setAlpha((int) (255 * (0.18f + 0.5f * level * (0.55f + 0.45f * beat))));
        c.drawCircle(cx, cy, w * 0.5f, glow);

        // ---- ঘুরন্ত ডিস্ক ----
        float R = R0 * (1f + 0.02f * beat);
        ring.setStrokeWidth(w * 0.05f);
        ring.setColor(color); ring.setAlpha((int) (40 + 50 * beat));
        c.drawCircle(cx, cy, R + w * 0.03f, ring);
        ring.setStrokeWidth(w * 0.016f);
        ring.setColor(color); ring.setAlpha(255);
        c.drawCircle(cx, cy, R + w * 0.012f, ring);

        c.save();
        c.rotate(ang, cx, cy);
        if (bmp != null) {
            if (shader == null || shaderBmp != bmp) {
                shader = new BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                shaderBmp = bmp;
            }
            float sc = 2 * R / Math.min(bmp.getWidth(), bmp.getHeight());
            m.reset(); m.setScale(sc, sc);
            m.postTranslate(cx - bmp.getWidth() * sc / 2, cy - bmp.getHeight() * sc / 2);
            shader.setLocalMatrix(m);
            p.setShader(shader);
            c.drawCircle(cx, cy, R, p);
        } else {
            if (phShader == null || phW != gw || phColor != color) {
                phW = gw; phColor = color;
                phShader = new LinearGradient(cx - R0, cy - R0, cx + R0, cy + R0, color, PlayerCore.accent2(), Shader.TileMode.CLAMP);
            }
            p.setShader(phShader);
            c.drawCircle(cx, cy, R, p);
            p.setShader(null);
            p.setColor(0xDDFFFFFF); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(R * 1.1f);
            c.drawText("♪", cx, cy + R * 0.38f, p);
        }
        p.setShader(null);
        groove.setStrokeWidth(Math.max(1f, w * 0.004f));
        groove.setColor(0x22000000);
        for (float g = 0.45f; g < 0.97f; g += 0.13f) c.drawCircle(cx, cy, R * g, groove);
        groove.setColor(0x33FFFFFF); groove.setStrokeWidth(w * 0.012f);
        c.drawArc(cx - R * 0.8f, cy - R * 0.8f, cx + R * 0.8f, cy + R * 0.8f, -60, 40, false, groove);
        c.restore();

        // ---- কভারের ওপর হালকা কালো পর্দা, যাতে বার স্পষ্ট দেখা যায় ----
        dim.setColor(0xFF000000);
        dim.setAlpha((int) (40 + 70 * level));
        c.drawCircle(cx, cy, R, dim);

        // ---- মাঝখানের দাগের ওপর ইকুয়ালাইজার ----
        float span = R * 1.62f;
        float slot = span / n;
        float bw = slot * 0.62f;
        float maxH = R * (small ? 0.78f : 0.70f);
        float minH = Math.max(w * 0.012f, 1.5f);
        float x0 = cx - span / 2f;
        boolean peakActive = false;
        for (int i = 0; i < n; i++) {
            int kk = Math.abs(i - half);
            float f = kk / (float) Math.max(half, 1);
            float s1 = 0.5f + 0.5f * (float) Math.sin(t * (2.3f + f * 4.9f) + i * 0.8f);
            float s2 = 0.5f + 0.5f * (float) Math.sin(t * (3.9f + f * 2.7f) + i * 1.9f);
            float nz = 0.55f * s1 + 0.45f * s2;
            float weight = (1f - f) * 0.55f + 0.45f;           // মাঝের বার বেশি লাফায়
            float env = 0.45f + 0.55f * (float) Math.cos(f * 1.35f); // কিনারার বার ছোট, গোল আকার বজায় রাখে
            float target = clamp((0.10f + 0.50f * nz + 0.42f * e * weight + 0.22f * e2 * (1f - f))) * env * level;
            lv[i] += (target - lv[i]) * (target > lv[i] ? 0.5f : 0.14f);
            if (lv[i] >= pk[i]) { pk[i] = lv[i]; pkv[i] = 0; }
            else { pkv[i] += 0.0022f; pk[i] -= pkv[i]; if (pk[i] < lv[i]) pk[i] = lv[i]; }
            if (pk[i] > 0.02f) peakActive = true;

            float bx = x0 + i * slot + (slot - bw) / 2f;
            float h = minH + lv[i] * maxH;
            int col = PlayerCore.mix(color, PlayerCore.accent2(), f);
            int hi = PlayerCore.mix(col, 0xFFFFFFFF, 0.55f);
            // ওপরের অংশ
            bar.setColor(col); bar.setAlpha(255);
            rf.set(bx, cy - h, bx + bw, cy - 1f);
            c.drawRoundRect(rf, bw / 2f, bw / 2f, bar);
            // মাথার উজ্জ্বল ক্যাপ
            bar.setColor(hi); bar.setAlpha(255);
            rf.set(bx, cy - h, bx + bw, cy - h + Math.min(bw * 0.9f, h));
            c.drawRoundRect(rf, bw / 2f, bw / 2f, bar);
            // নিচের অংশ: ঝাপসা প্রতিফলন
            bar.setColor(col); bar.setAlpha(80);
            rf.set(bx, cy + 1f, bx + bw, cy + h * 0.8f);
            c.drawRoundRect(rf, bw / 2f, bw / 2f, bar);
            // ভেসে থাকা পিক ডট
            if (pk[i] > 0.04f && !small) {
                float py = cy - minH - pk[i] * maxH - bw * 1.2f;
                dot.setAlpha((int) (220 * Math.min(1f, pk[i] * 2f)));
                c.drawCircle(bx + bw / 2f, py, bw * 0.38f, dot);
            }
        }
        // মাঝের উজ্জ্বল দাগ
        axis.setStrokeWidth(Math.max(1.5f, w * 0.008f));
        axis.setColor(0xFFFFFFFF); axis.setAlpha((int) (90 + 120 * level));
        c.drawLine(x0 - slot, cy, x0 + span + slot, cy, axis);

        // ---- মাঝের ছিদ্র বাদ: দাগ পরিষ্কার দেখানোর জন্য ছোট কেন্দ্র-বিন্দু শুধু বড় ভিউতে নেই ----
        if (spin) ang = (ang + 0.7f) % 360;
        if (spin || level > 0.01f || peakActive) postInvalidateOnAnimation();
    }
}
