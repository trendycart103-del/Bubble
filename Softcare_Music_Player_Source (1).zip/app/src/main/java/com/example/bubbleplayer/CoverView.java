package com.example.bubbleplayer;

import android.content.Context;
import android.graphics.*;
import android.view.View;

/**
 * ঘুরন্ত কভার + চারপাশে ছন্দে নাচা রঙিন ভিজুয়ালাইজার।
 * ভিজুয়ালাইজার সিনথেটিক: গানের অবস্থান (PlayerCore.pos) থেকে বিট ও ঢেউ হিসাব করে, তাই কোনো অতিরিক্ত পারমিশন লাগে না।
 * গান থামালে বারগুলো নরমভাবে নেমে যায়, সিক করলে ছন্দও সেই অনুযায়ী বদলায়।
 */
public class CoverView extends View {
    static final int NB = 48, NB_SMALL = 24;
    Bitmap bmp; boolean spin; int color = 0xFF4FC3F7; float ang;
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), ring = new Paint(Paint.ANTI_ALIAS_FLAG), groove = new Paint(Paint.ANTI_ALIAS_FLAG);
    Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG), glow = new Paint(Paint.ANTI_ALIAS_FLAG), dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    Matrix m = new Matrix();
    float[] lv = new float[NB], pk = new float[NB], pkv = new float[NB];
    float level;
    BitmapShader shader; Bitmap shaderBmp;
    Shader glowShader; int glowColor, glowW = -1;
    Shader phShader; int phColor, phW = -1;

    public CoverView(Context c) {
        super(c);
        ring.setStyle(Paint.Style.STROKE);
        groove.setStyle(Paint.Style.STROKE);
        bar.setStyle(Paint.Style.STROKE);
        bar.setStrokeCap(Paint.Cap.ROUND);
        dot.setStyle(Paint.Style.FILL);
        dot.setColor(Color.WHITE);
    }

    void set(Bitmap b, boolean s, int col) {
        bmp = b; spin = s; color = col;
        if (s || level > 0.01f) postInvalidateOnAnimation(); else invalidate();
    }

    static float clamp(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), cx = w / 2, cy = getHeight() / 2;
        if (w <= 0) return;
        boolean small = w < 110 * getResources().getDisplayMetrics().density;
        int n = small ? NB_SMALL : NB, half = n / 2;
        float R0 = w * (small ? 0.33f : 0.30f);

        // ---- বিট ও লেভেল ----
        int posMs = 0;
        try { posMs = PlayerCore.pos(); } catch (Exception ignored) {}
        float t = posMs / 1000f;
        float bpm = 96 + (Math.abs(PlayerCore.idx * 37) % 48);
        float bph = (posMs * bpm / 60000f) % 1f;
        float e = (float) Math.pow(1f - bph, 3);
        float e2 = (float) Math.pow(1f - ((bph * 2f) % 1f), 4) * 0.5f;
        level += ((spin ? 1f : 0f) - level) * 0.08f;
        float beat = e * level;

        // ---- নরম গ্লো ----
        int gw = (int) w;
        if (glowShader == null || glowW != gw || glowColor != color) {
            glowW = gw; glowColor = color;
            glowShader = new RadialGradient(cx, cy, w * 0.5f, (color & 0x00FFFFFF) | 0xAA000000, 0x00000000, Shader.TileMode.CLAMP);
            glow.setShader(glowShader);
        }
        glow.setAlpha((int) (255 * (0.18f + 0.55f * level * (0.55f + 0.45f * beat))));
        c.drawCircle(cx, cy, w * 0.5f, glow);

        float inner = R0 * 1.16f;
        float minLen = w * (small ? 0.014f : 0.012f);
        float maxLen = Math.max(w * 0.5f - inner - w * 0.012f - minLen, 1f);

        // ---- বিটে ছড়িয়ে পড়া ঢেউ-রিং ----
        if (level > 0.05f && !small) {
            float rr = inner + minLen + bph * (w * 0.5f - inner - minLen);
            ring.setStrokeWidth(w * 0.008f);
            ring.setColor(PlayerCore.accent2());
            ring.setAlpha((int) ((1f - bph) * 110 * level));
            c.drawCircle(cx, cy, rr, ring);
        }

        // ---- ভিজুয়ালাইজার বার ----
        bar.setStrokeWidth(Math.max(1.5f, (float) (2 * Math.PI * inner / n) * 0.52f));
        boolean peakActive = false;
        for (int i = 0; i < n; i++) {
            int kk = i <= half ? i : n - i;
            float f = kk / (float) half;
            float s1 = 0.5f + 0.5f * (float) Math.sin(t * (2.1f + f * 5.3f) + kk * 0.9f);
            float s2 = 0.5f + 0.5f * (float) Math.sin(t * (3.7f + f * 2.9f) + kk * 1.7f);
            float nz = 0.55f * s1 + 0.45f * s2;
            float weight = (1f - f) * 0.6f + 0.4f;
            float target = clamp((0.10f + 0.50f * nz + 0.42f * e * weight + 0.22f * e2 * f) ) * level;
            lv[i] += (target - lv[i]) * (target > lv[i] ? 0.5f : 0.15f);
            if (lv[i] >= pk[i]) { pk[i] = lv[i]; pkv[i] = 0; }
            else { pkv[i] += 0.0025f; pk[i] -= pkv[i]; if (pk[i] < lv[i]) pk[i] = lv[i]; }
            if (pk[i] > 0.02f) peakActive = true;

            double a = Math.toRadians(i * 360.0 / n - 90.0);
            float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
            float len = minLen + lv[i] * maxLen;
            bar.setColor(PlayerCore.mix(color, PlayerCore.accent2(), f));
            bar.setAlpha((int) (150 + 100 * lv[i]));
            c.drawLine(cx + ca * inner, cy + sa * inner, cx + ca * (inner + len), cy + sa * (inner + len), bar);
            if (pk[i] > 0.04f && !small) {
                float pr = inner + minLen + pk[i] * maxLen + w * 0.022f;
                dot.setAlpha((int) (200 * Math.min(1f, pk[i] * 2f)));
                c.drawCircle(cx + ca * pr, cy + sa * pr, bar.getStrokeWidth() * 0.4f, dot);
            }
        }

        // ---- ঘুরন্ত ডিস্ক ----
        float R = R0 * (1f + 0.025f * beat);
        ring.setStrokeWidth(w * 0.05f);
        ring.setColor(color); ring.setAlpha((int) (40 + 50 * beat));
        c.drawCircle(cx, cy, R + w * 0.03f, ring);
        ring.setStrokeWidth(w * 0.016f);
        ring.setColor(color); ring.setAlpha(255);
        c.drawCircle(cx, cy, R + w * 0.012f, ring);

        c.save();
        c.rotate(ang, cx, cy);
        if (bmp != null) {
            if (shader == null || shaderBmp != bmp) {
                shader = new BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                shaderBmp = bmp;
            }
            float sc = 2 * R / Math.min(bmp.getWidth(), bmp.getHeight());
            m.reset(); m.setScale(sc, sc);
            m.postTranslate(cx - bmp.getWidth() * sc / 2, cy - bmp.getHeight() * sc / 2);
            shader.setLocalMatrix(m);
            p.setShader(shader);
            c.drawCircle(cx, cy, R, p);
        } else {
            if (phShader == null || phW != gw || phColor != color) {
                phW = gw; phColor = color;
                phShader = new LinearGradient(cx - R0, cy - R0, cx + R0, cy + R0, color, PlayerCore.accent2(), Shader.TileMode.CLAMP);
            }
            p.setShader(phShader);
            c.drawCircle(cx, cy, R, p);
            p.setShader(null);
            p.setColor(0xDDFFFFFF); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(R * 1.1f);
            c.drawText("♪", cx, cy + R * 0.38f, p);
        }
        p.setShader(null);
        groove.setStrokeWidth(Math.max(1f, w * 0.004f));
        groove.setColor(0x22000000);
        for (float g = 0.45f; g < 0.97f; g += 0.13f) c.drawCircle(cx, cy, R * g, groove);
        groove.setColor(0x33FFFFFF); groove.setStrokeWidth(w * 0.012f);
        c.drawArc(cx - R * 0.8f, cy - R * 0.8f, cx + R * 0.8f, cy + R * 0.8f, -60, 40, false, groove);
        c.restore();
        p.setColor(0xFF0B1220);
        c.drawCircle(cx, cy, R * 0.14f, p);
        p.setColor(color); p.setAlpha(200);
        c.drawCircle(cx, cy, R * 0.05f, p);
        p.setAlpha(255);

        if (spin) ang = (ang + 0.7f) % 360;
        if (spin || level > 0.01f || peakActive) postInvalidateOnAnimation();
    }
}
